'use strict';
// Decrypts a downloaded backup: node scripts/restore.js epsilon-backup-YYYY-MM-DD.enc
// It writes data/store.restored.json; it never overwrites the live data by itself.
const fs = require('fs'), path = require('path'), crypto = require('crypto'), readline = require('readline');
const file = process.argv[2]; if (!file) { console.log('Usage: node scripts/restore.js <backup file>'); process.exit(1); }
const buf = fs.readFileSync(file);
if (buf.slice(0, 4).toString() !== 'EPS1') { console.log('This is not an Epsilon backup file.'); process.exit(1); }
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl.question('Backup passphrase: ', pass => {
  rl.close();
  try {
    const salt = buf.slice(4, 20), iv = buf.slice(20, 32), tag = buf.slice(32, 48), enc = buf.slice(48);
    const d = crypto.createDecipheriv('aes-256-gcm', crypto.scryptSync(pass, salt, 32), iv); d.setAuthTag(tag);
    const json = Buffer.concat([d.update(enc), d.final()]).toString('utf8'); JSON.parse(json);
    const out = path.join(__dirname, '..', 'data', 'store.restored.json'); fs.writeFileSync(out, json);
    console.log('Decrypted OK: ' + out);
    console.log('To use it: systemctl stop epsilon && cp data/store.restored.json data/store.json && systemctl start epsilon');
  } catch (e) { console.log('Could not decrypt: wrong passphrase or damaged file.'); process.exit(1); }
});
