# Switching on emails (Brevo, free up to 300 emails a day)

Menu names on Brevo may differ slightly from these.

## 1. Create the Brevo account and verify your domain (about 15 minutes)
1. Sign up at brevo.com. Accept its data processing terms (DPA) in the account or legal settings.
2. Open **Senders, Domains & Dedicated IPs → Domains → Add a domain** and enter `epsilonacademy.co.uk`.
3. Brevo shows 2 to 4 DNS records. In **Cloudflare → epsilonacademy.co.uk → DNS → Records**, add each one exactly as shown, with **Proxy: DNS only** (grey cloud).
   - Do not delete any existing records.
   - If Brevo asks you to change an existing SPF (TXT) record, add Brevo's part to it rather than replacing it.
4. Back in Brevo, press **Verify / Authenticate**. It may take a few minutes.
5. Under **Senders**, add `hello@epsilonacademy.co.uk` (or another address on your domain).

## 2. Create an API key
Go to **SMTP & API → API keys → Generate a new API key**. Copy it. Do not paste it into chat.

## 3. Add it on the VPS
```
cd /opt/epsilon-app && nano config.json
```
Add these lines inside the `{ }`. Put a comma at the end of the line above them.
```
"EMAIL_PROVIDER": "brevo",
"EMAIL_KEY": "paste-the-key",
"EMAIL_FROM": "hello@epsilonacademy.co.uk",
"EMAIL_FROM_NAME": "Epsilon Academy"
```
To save, press **Ctrl+O**, then **Enter**. To exit, press **Ctrl+X**. Then run:
```
systemctl restart epsilon
```

## 4. Test, then switch on
1. In the Control Room, the **Emails** card should say "Set up".
2. Press **Send test email to me** and check your inbox (and spam folder).
3. Enter your DSL's email and press **Save DSL email**.
4. Tick **Send emails**.

Postmark works the same way: use `"EMAIL_PROVIDER": "postmark"` and its Server API token.
