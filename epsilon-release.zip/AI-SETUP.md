# Switching on the AI coach

The AI never sees names or emails. Each student is sent as a code number (S-######), and replies are matched back on your server.

## Before you start
- Tick the AI item on the pre-pilot checklist first: a paid plan that does not train on your data, signed data processing terms, the transfer safeguard, and privacy notice section 7 filled in.
- Create a **new** API key. The old Gemini key was exposed in chat, so never use it.
- Never paste the key into chat, GitHub or email. It goes only into `config.json` on the VPS.

## Step 1: add the key on the VPS
```
cd /opt/epsilon-app && nano config.json
```
Add these three lines inside the `{ }`, after the existing lines. Put a comma at the end of the line above them.

For Claude (Anthropic):
```
"AI_PROVIDER": "anthropic",
"AI_KEY": "paste-your-new-key-here",
"AI_MODEL": "claude-haiku-4-5-20251001"
```
Or for Gemini (Google):
```
"AI_PROVIDER": "gemini",
"AI_KEY": "paste-your-new-key-here",
"AI_MODEL": "gemini-flash-latest"
```
To save, press **Ctrl+O**, then **Enter**. To exit, press **Ctrl+X**.

## Step 2: restart and check
```
systemctl restart epsilon && sleep 2 && systemctl is-active epsilon
```
In the Control Room, the Switchboard should say "AI: set up".

## Step 3: switch it on for a student
1. In the Switchboard, tick **AI coach on**. Leave "Show AI tips to students without approval" unticked.
2. Under a student, choose **AI coach (code number only)**, then press **Allocate** and **Run now**.
3. Check "What was sent to the AI", then edit the tip if needed and press **Approve**.

## Optional switches (off by default)
- **Send typed answers and working:** names, emails, phone numbers, links and postcodes are removed first. School or street names a child types are not always caught.
- **Send wellbeing flags:** sent in the system's own words. The AI keeps the tip gentle and never mentions it to the student. Your DSL still handles every concern.
