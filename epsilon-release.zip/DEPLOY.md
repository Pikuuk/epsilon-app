# Deploy Epsilon Academy (VPS + Cloudflare)

The app goes on its own address: **https://app.epsilonacademy.co.uk**
Your website (www) and your other VPS projects are not touched.

Type each grey box into the terminal exactly, then press Enter.

## A. Cloudflare: create the app address (5 min)
1. Go to dash.cloudflare.com → **epsilonacademy.co.uk** → **DNS** → **Records**.
2. Check whether a record named `app` already exists. If it does, stop and tell Claude.
3. Press **Add record** and fill in:
   - **Type:** `A`
   - **Name:** `app`
   - **IPv4:** your VPS IP (Hostinger hPanel → VPS → Overview)
   - **Proxy:** click the cloud so it is **grey** (DNS only)
4. Press **Save**. Do not change any other record.

## B. VPS: get the files via GitHub
**B1. Put the files on GitHub (in your browser, one time)**
1. Unzip `epsilon-server.zip` on your computer.
2. On github.com, press **New repository**. Name it `epsilon-app`, choose **Private**, and press **Create**.
3. Click **uploading an existing file**. Open the unzipped `epsilon-server` folder, select **everything inside it** (files and folders, including `.gitignore`), and drag it onto the page.
4. Press **Commit changes**.

**B2. Let the VPS read it (one time)**
In Hostinger hPanel → VPS, open **Browser terminal** and type:
```
apt-get install -y git
ssh-keygen -t ed25519 -f ~/.ssh/epsilon_deploy -N ""
cat ~/.ssh/epsilon_deploy.pub
```
1. Copy the line that starts with `ssh-ed25519`. It is safe to share.
2. On GitHub, open your `epsilon-app` repo → **Settings** → **Deploy keys** → **Add deploy key**.
3. Title it `VPS`, paste the line, leave **Allow write access** unticked, and press **Add key**.

**B3. Download and install**
In the commands below, replace `YOURNAME` with your GitHub username:
```
git clone -c core.sshCommand="ssh -i ~/.ssh/epsilon_deploy -o StrictHostKeyChecking=accept-new" git@github.com:YOURNAME/epsilon-app.git /opt/epsilon-app
cd /opt/epsilon-app
cp config.example.json config.json
nano config.json
```
1. Change the email and name to your own.
2. Save with **Ctrl+O**, then **Enter**, then exit with **Ctrl+X**.

Then install:
```
bash scripts/install.sh
```
- If it says the port is in use, change `8787` to `8788` in `config.json` and run it again.
- To get your one-time password, write down what this shows:
```
journalctl -u epsilon-app | grep -A5 "FIRST RUN"
```

**Updating later (the release file method):** you will get one file, `epsilon-release.zip`.
1. On github.com, open the main page of `epsilon-app`, then **Add file → Upload files**.
2. Drag that one zip file in and press **Commit changes**.
3. On the VPS, run:
```
cd /opt/epsilon-app && git pull && unzip -o epsilon-release.zip && systemctl restart epsilon && sleep 2 && systemctl is-active epsilon && cat VERSION
```
Your data and settings are never touched.

## C. VPS: find out which web server you already have
```
ss -ltnp | grep -E ':80 |:443 '; docker ps --format '{{.Names}} {{.Ports}}' 2>/dev/null
```
Read the result:
- **It mentions `nginx`:** do C1.
- **It mentions `caddy`, or a Docker container using ports 80/443:** stop and paste the output to Claude. You will get the exact 2–3 lines for your setup.
- **It shows nothing:** do C1.

### C1. Connect the address and the padlock (nginx)
Paste this whole block. It adds one new file and does not change your other sites:
```
apt-get install -y nginx certbot python3-certbot-nginx
cat > /etc/nginx/sites-available/epsilon-app <<'NG'
server {
  listen 80;
  server_name app.epsilonacademy.co.uk;
  location / {
    proxy_pass http://127.0.0.1:8787;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
NG
ln -sf /etc/nginx/sites-available/epsilon-app /etc/nginx/sites-enabled/epsilon-app
nginx -t && systemctl reload nginx
certbot --nginx -d app.epsilonacademy.co.uk
```
- If you changed the port to 8788 in step B4, change `8787` to `8788` in this block before pasting.
- If `nginx -t` shows an error, stop and paste it to Claude. Your other sites keep running.
- Certbot asks three things: type your email, then **Y**, then **N**.

## D. First sign-in and loading the questions
1. Open **https://app.epsilonacademy.co.uk/login.html** and sign in with your email and the one-time password. Set your own password.
2. Load the Year 7 Maths questions:
```
cd /opt/epsilon-app && node scripts/import-content.js content/year7-maths-approved.json
```
   You should see "Imported 104".

## E. Add Login and Join to your website (www)
Add two buttons (or change your existing Login button):

| Button | Link |
|---|---|
| **Log in** | `https://app.epsilonacademy.co.uk/login.html` |
| **Join** | `https://app.epsilonacademy.co.uk/request.html` |

- **Website builder:** edit the button link and publish.
- **Code (for example, the website files on this VPS or a GitHub repo):** send Claude the file with the menu or header. Claude returns it with the buttons added.

## Handy commands
- **Logs:** `journalctl -u epsilon-app -n 50`
- **Restart:** `systemctl restart epsilon-app`
- **Back up now:** `cd /opt/epsilon-app && node scripts/backup.js`

## Before real children use it
Complete the privacy notice (`/privacy.html`), run a DPIA, and record parental consent for each child in the Control Room.
