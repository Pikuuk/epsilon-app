/* Epsilon Discovery (Nova, Orion, Vega, Lyra): questions, rules and analysis, lifted from the tested prototype. */
(function(g){
'use strict';
function trim(x){return String(x).trim()}
function esc(t){return String(t==null?'':t).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function yearNum(y){return parseInt(String(y).replace(/\D/g,""),10)||9}
function bandOf(y){var n=yearNum(y);return n<=9?"KS3":n<=11?"KS4":"KS5"}
function fmtHour(h){if(h>=24)h-=24;if(h<0)h+=24;var hh=Math.floor(h),mm=Math.round((h-hh)*60);if(mm===60){hh++;mm=0}var ap=hh>=12?"pm":"am",h12=hh%12===0?12:hh%12;return h12+(mm?":"+(mm<10?"0":"")+mm:"")+ap}
function defaultBank(){
  var Y=["KS3","KS4","KS5"];
  function Q(id,mod,scope,kind,text,x){var q={id:id,mod:mod,scope:scope,kind:kind,text:text,construct:"",reverse:false,opts:[],years:Y.slice(),showIf:null,flag:null,report:false};for(var k in x)q[k]=x[k];return q}
  function O(l,v){return {l:l,v:v}}
  return [
    Q("A0","A","student","choice","How are you feeling about school and studying at the moment?",{report:true,opts:[O("Pretty good","good"),O("OK","ok"),O("A bit stressed","stress"),O("Often overwhelmed","over"),O("I would rather not say","skip")],flag:{op:"in",val:["over"],type:"wellbeing",msg:"Said they often feel overwhelmed about school or studying."}}),
    Q("A1","A","subject","scale","I feel confident I can do well in {subject} if I work at it.",{construct:"SE"}),
    Q("A2","A","subject","choice","What makes {subject} feel hardest?",{report:true,showIf:{q:"A1",op:"lte",val:2},opts:[O("I get lost in the explanations","lost"),O("I forget things quickly","forget"),O("I run out of time in tests","time"),O("I do not see the point","point"),O("I worry about getting it wrong","nervous"),O("Not sure","unsure")]}),
    Q("A3","A","subject","scale","I think {subject} will be useful to me in the future.",{construct:"TV"}),
    Q("A4","A","subject","scale","I enjoy learning new things in {subject}.",{construct:"TV"}),
    Q("A5","A","subject","scale","I can get better at {subject} with practice, even if I find it hard now.",{construct:"GB"}),
    Q("A6","A","subject","scale","I care more about understanding {subject} than about the mark I get.",{construct:"GO"}),
    Q("A7","A","subject","scale","I feel nervous or worried before {subject} tests.",{construct:"TA"}),
    Q("A8","A","subject","choice","What helps most when you feel nervous about {subject}?",{report:true,showIf:{q:"A7",op:"gte",val:4},opts:[O("Talking to someone","talk"),O("Practising exam-style questions","practise"),O("A short break or slow breathing","break"),O("Not sure","unsure"),O("Nothing seems to help","none")],flag:{op:"in",val:["none"],type:"note",msg:"Very nervous about tests and nothing seems to help. Suggest a teacher check-in."}}),
    Q("A9","A","subject","scale","When {subject} gets difficult, I keep trying instead of giving up.",{construct:"EF"}),
    Q("A10","A","subject","scale","I ask for help in {subject} when I am stuck.",{construct:"HS"}),
    Q("A11","A","subject","choice","What stops you asking for help in {subject}?",{report:true,showIf:{q:"A10",op:"lte",val:2},opts:[O("I feel embarrassed","embarrassed"),O("I do not know what to ask","noask"),O("There is no one to ask","noone"),O("I do not want to bother anyone","bother"),O("I am not stuck often","notstuck")]}),
    Q("A12","A","subject","scale","I know what I need to do to reach my target grade in {subject}.",{construct:"CL",years:["KS4","KS5"]}),
    Q("B1","B","student","multi","When you revise, which of these do you actually do? Tick all that apply.",{report:true,opts:[O("Read my notes or textbook again","reread"),O("Highlight or underline","highlight"),O("Make new notes or summaries","notes"),O("Quiz myself with flashcards or questions","flashcards"),O("Do past paper or exam-style questions","pastpapers"),O("Explain it out loud to someone or myself","teach"),O("Draw diagrams, timelines or mind maps","diagrams"),O("Mix different topics in one session","mix"),O("Plan my revision across several days","plan"),O("I do not really revise yet","none")]}),
    Q("B2","B","student","choice","When do you usually revise for a test?",{report:true,opts:[O("Mostly the night before","cram"),O("In the few days before","short"),O("Little and often, over a couple of weeks or more","spread")]}),
    Q("B3","B","student","choice","After revising, how do you check you really know it?",{report:true,opts:[O("I do not check","none"),O("I read it again and it feels familiar","reread"),O("I test myself without looking","quiz"),O("I do exam-style questions and mark them","past")]}),
    Q("B4","B","student","choice","What makes testing yourself hard?",{report:true,showIf:{q:"B3",op:"in",val:["none","reread"]},opts:[O("I do not know how to do it","how"),O("I have no time","time"),O("I do not like getting things wrong","wrong"),O("I do not have questions to use","materials")]}),
    Q("B5","B","student","choice","When you get a question wrong, what do you usually do?",{report:true,opts:[O("Move on","ignore"),O("Look at the answer and move on","answer"),O("Work out why I got it wrong, then try a similar one","why"),O("Ask someone to help","help")]}),
    Q("B6","B","student","scale","I can explain a topic to someone else without looking at my notes.",{construct:"FE"}),
    Q("B7","B","student","choice","Do you turn your notes into diagrams, flow charts or timelines?",{opts:[O("Never","never"),O("Sometimes","sometimes"),O("Often","often")]}),
    Q("B8","B","student","choice","When a topic feels too big, what do you do?",{report:true,opts:[O("Put it off","avoid"),O("Try to do all of it at once","push"),O("Split it into smaller parts and do one at a time","split")]}),
    Q("C1","C","student","choice","What time do you usually go to sleep on school nights?",{opts:[O("Before 9pm",20.5),O("9pm to 10pm",21.5),O("10pm to 11pm",22.5),O("11pm to midnight",23.5),O("After midnight",24.5)]}),
    Q("C2","C","student","choice","What time do you usually wake up on school days?",{opts:[O("Before 6:30am",6),O("6:30am to 7:30am",7),O("After 7:30am",8)]}),
    Q("C3","C","student","choice","Once in bed, how long does it usually take you to fall asleep?",{opts:[O("Under 15 minutes",10),O("15 to 30 minutes",25),O("30 to 60 minutes",45),O("More than an hour",75)],flag:{op:"gte",val:75,type:"sleep",msg:"Often takes more than an hour to fall asleep. Suggest a parent conversation about sleep."}}),
    Q("C4","C","student","choice","When do you feel most awake and focused?",{report:true,opts:[O("Morning","morning"),O("Afternoon","afternoon"),O("Evening","evening"),O("It changes","varies")]}),
    Q("C5","C","student","choice","How often do you study or do homework after 9pm on school nights?",{report:true,opts:[O("Never","never"),O("Sometimes","sometimes"),O("Often","often")]}),
    Q("C6","C","student","choice","Do you use a phone or screen in the last 30 minutes before sleep?",{opts:[O("No","no"),O("Sometimes","sometimes"),O("Almost always","always")]}),
    Q("C7","C","student","choice","How often do you have energy drinks, coffee or cola in the afternoon or evening?",{opts:[O("Rarely or never","rarely"),O("Sometimes","sometimes"),O("Often","often")],flag:{op:"in",val:["often"],type:"caffeine",msg:"Often has caffeinated drinks in the afternoon or evening."}}),
    Q("D1","D","student","choice","Where do you usually study?",{report:true,opts:[O("A desk or table in a quiet room","desk"),O("Kitchen or living room with others around","shared"),O("Bed or sofa","bed"),O("It changes","varies")]}),
    Q("D2","D","student","choice","Where is your phone while you study?",{report:true,opts:[O("Silent and out of reach","away"),O("Silent but nearby","near"),O("Notifications on or in my hand","on")]}),
    Q("D3","D","student","choice","Do you have a regular study time?",{opts:[O("Same time most days","same"),O("Different times","varies"),O("No set time","none")]}),
    Q("D4","D","student","choice","How do you take breaks when studying?",{opts:[O("Planned short breaks","planned"),O("Only when I get stuck","stuck"),O("Rarely","rare")]}),
    Q("D5","D","student","choice","Before you study, have you usually eaten and had some water?",{opts:[O("Usually yes","ok"),O("Sometimes I am hungry or thirsty","hungry"),O("Often not","often")]}),
    Q("D6","D","student","choice","What do you have on while you study?",{opts:[O("Nothing","none"),O("Music without words","music"),O("Songs with words","songs"),O("Videos or streams","video")]}),
    Q("D7","D","student","choice","Is your study spot well lit and comfortable?",{opts:[O("Yes","good"),O("Not really","poor"),O("It changes","varies")]}),
    Q("D8","D","student","choice","Would it help if a parent or carer checked in with you while you study?",{opts:[O("Yes","yes"),O("Maybe","maybe"),O("No thanks","no")]}),
    Q("D9","D","student","text","Is there anything you would like your teacher to know? (optional)",{}),
    Q("E1","E","weekly","scale","This week I understood most of my {subject} work.",{construct:"UN"}),
    Q("E2","E","weekly","scale","I could answer {subject} questions without looking at my notes.",{construct:"RC"}),
    Q("E3","E","weekly","scale","I feel confident about {subject} right now.",{construct:"CF"}),
    Q("E4","E","weekly","choice","What was hardest about {subject} this week?",{report:true,showIf:{q:"E1",op:"lte",val:3},opts:[O("Understanding new ideas","understand"),O("Remembering things","remember"),O("Finding time","time"),O("Staying focused","focus"),O("Nothing was hard","none")]}),
    Q("E5","E","weekly","scale","{subject} felt stressful this week.",{flag:{op:"gte",val:5,type:"wellbeing",msg:"Said {subject} felt very stressful this week."}})
  ];
}
function defaultRules(){
  function C(label,low,mid,high){return {label:label,low:low,mid:mid,high:high}}
  function M(label,ev,tip){return {label:label,ev:ev,tip:tip}}
  function R(id,aud,text,q,op,val){return {id:id,aud:aud,text:text,q:q,op:op,val:val}}
  return {
    alias:{A:"Nova",B:"Orion",C:"Vega",D:"Lyra",E:"Sirius",R:"Rigel"},
    mark:{sample:0.25},
    att:{grace:15,limit:3},
    mail:{
      missed:"Hi {name}, we did not see you log in for your {session} session (planned for {time}). Please log in when you can. If something got in the way, your parent can tell us.",
      warn:"Hello. {name} has missed {n} sessions in a row. If {limit} in a row are missed, access is paused. If there is a reason, please send an explanation from your account.",
      paused:"{name}'s access is paused after {limit} missed sessions in a row. A parent can send an explanation and a teacher will review it.",
      explanation:"A parent sent an explanation for {name}'s missed {session} session: {text}",
      accepted:"The explanation for {name}'s missed {session} session was accepted. It will not count.",
      rejected:"The explanation for {name}'s missed {session} session was reviewed and not accepted. Note: {note}",
      restored:"{name}'s access has been restored. Welcome back."
    },
    thr:{low:2.5,high:3.75},
    sleep:{yMin:9,yMax:12,tMin:8,tMax:10,gap:1},
    msgWellbeing:"Thanks for telling us. A teacher will check in with you soon. If you want to talk to someone today, tell a trusted adult, or call Childline free on 0800 1111.",
    priority:["recall","spacing","meta","sleep","chunk","feynman","dual","interleave"],
    constructs:{
      SE:C("Confidence in the subject","Doubts they can do well. Start with small, winnable tasks and show progress often.","Fairly confident, but wobbles on harder work. Mix easy wins with stretch questions.","Confident. Keep the challenge up and check with a quick diagnostic."),
      TV:C("Sees the point and enjoys it","Sees little point or interest. Link topics to real uses and to their own goals.","Some interest. Connect topics to what they care about.","Values and enjoys the subject."),
      GB:C("Believes practice improves results","May feel ability is fixed. Praise strategies and effort, and show past improvement.","Mixed belief. Use before-and-after examples of their own work.","Believes practice pays off."),
      GO:C("Focus on understanding","Focused mainly on marks. Add understanding goals to each task.","Balances marks and understanding.","Motivated by understanding, which supports deeper learning."),
      TA:C("Test nerves (higher means more nervous)","Rarely nervous before tests.","Some test nerves. Include low-stakes practice quizzes.","Often nervous before tests. Use frequent low-stakes quizzes and teach a calming routine. Consider a teacher check-in."),
      EF:C("Persistence","Gives up when work gets hard. Break tasks into steps and check in early.","Keeps going most of the time. Watch for drop-off on long tasks.","Keeps going when it gets hard."),
      HS:C("Asks for help","Rarely asks for help. Give an easy way to say I am stuck.","Sometimes asks for help. Normalise asking early.","Asks for help when stuck."),
      CL:C("Knows the route to the target grade","Unsure how to reach the target. Set a clear, stepwise goal.","Partly clear. Map topics to marks.","Clear on what to do next."),
      FE:C("Can explain without notes","Cannot yet explain without notes. Use explain-it-back tasks.","Can explain some topics. Add regular explain-it-back.","Can explain topics without notes."),
      UN:C("Understood this week's work","Found this week's work hard to follow. Revisit the ideas before adding more.","Understood some of it. Check the weaker parts.","Understood most of it."),
      RC:C("Could answer without notes","Needed notes for most answers. More self-testing, in short bursts.","Could answer some questions unaided.","Could answer most questions unaided."),
      CF:C("Confidence now","Confidence is low right now. Small wins first.","Reasonably confident.","Confident.")
    },
    methods:{
      recall:M("Active recall (practice testing)","Strong: rated high utility by Dunlosky et al. (2013)","Close the notes and answer questions from memory, then check and fix gaps."),
      spacing:M("Spaced repetition (spread over days)","Strong: rated high utility by Dunlosky et al. (2013)","Revisit each topic after 1 day, 3 days, then a week. Little and often beats one long session."),
      meta:M("Metacognitive reflection","Strong: EEF reports about +7 months when taught well, best alongside subject content","After each task ask: what worked, what was hard, what will I change next time?"),
      interleave:M("Interleaving (mixing topics)","Moderate: rated moderate, evidence still developing","Once the basics are secure, mix question types from different topics in one session."),
      feynman:M("Explain it (Feynman style)","Moderate: self-explanation rated moderate","Explain the topic out loud in simple words. Where you stumble is what to revisit."),
      dual:M("Dual coding (words and visuals)","Limited as a self-study trick: imagery for reading was rated low. We use diagrams inside the materials we give you.","Draw the topic as a diagram from memory, then compare with your notes."),
      chunk:M("Chunking (small steps)","Not tested in this research pass. Sensible for limited working memory; treat as a teacher-approved habit.","Split a big topic into 3 to 5 small parts and finish one at a time."),
      sleep:M("Sleep","Strong for health: AASM advises 8 to 10 hours for ages 13 to 18","Keep a regular bedtime and finish studying about an hour before bed.")
    },
    reminders:[
      R("S1","student","Put your phone on silent and out of reach while you study.","D2","in",["near","on"]),
      R("S2","student","Try a fixed study time each day so it becomes a habit.","D3","in",["varies","none"]),
      R("S3","student","Take a short break every 25 to 40 minutes. Adjust to what works for you.","D4","in",["stuck","rare"]),
      R("S4","student","Eat and drink some water before you start.","D5","in",["hungry","often"]),
      R("S5","student","Aim to finish studying at least an hour before bed.","C5","in",["sometimes","often"]),
      R("S6","student","Avoid energy drinks and caffeine, especially after school.","C7","in",["sometimes","often"]),
      R("S7","student","Switch screens off 30 minutes before sleep.","C6","in",["sometimes","always"]),
      R("S8","student","Study somewhere quiet and clear of clutter.","D1","in",["shared","bed","varies"]),
      R("S9","student","Try silent or instrumental study, without songs or videos.","D6","in",["songs","video"]),
      R("S10","student","Check your light is bright enough and you are sitting upright.","D7","in",["poor","varies"]),
      R("P1","parent","Help set up a quiet study spot away from distractions.","D1","in",["shared","bed","varies"]),
      R("P2","parent","Agree a phone-free study time together.","D2","in",["near","on"]),
      R("P3","parent","Encourage screens off 30 minutes before sleep and a regular bedtime.","C6","in",["sometimes","always"]),
      R("P4","parent","A gentle daily check-in helps. Your child said they would welcome it.","D8","eq","yes"),
      R("P5","parent","Please help cut back on energy drinks and caffeine, especially after school.","C7","in",["sometimes","often"])
    ]
  };
}
function alias(k){return (S.rules.alias&&S.rules.alias[k])||k}
function condOK(c,a){
  if(!c||!c.op)return false;
  if(a===undefined||a===null||a===""||(Array.isArray(a)&&!a.length))return false;
  var v=c.val;
  if(c.op==="lte")return Number(a)<=Number(v);
  if(c.op==="gte")return Number(a)>=Number(v);
  if(c.op==="eq")return String(a)===String(Array.isArray(v)?v[0]:v);
  if(c.op==="in"){var arr=(Array.isArray(v)?v:String(v).split(",")).map(trim);var aa=Array.isArray(a)?a:[a];return aa.some(function(x){return arr.indexOf(String(x))>-1})}
  return false;
}
function listFor(scope,band){
  var order="ABCDE";
  return S.bank.filter(function(q){return q.scope===scope&&q.years.indexOf(band)>-1}).sort(function(a,b){return (order.indexOf(a.mod)-order.indexOf(b.mod))||(S.bank.indexOf(a)-S.bank.indexOf(b))});
}
function isVisible(q,eff){return !q.showIf||!q.showIf.q||condOK(q.showIf,eff[q.showIf.q])}
function effOf(list,ans){var eff={};list.forEach(function(q){if(isVisible(q,eff)&&ans[q.id]!==undefined)eff[q.id]=ans[q.id]});return eff}
function nextIdx(list,ans,from){var eff={},i;for(i=0;i<from&&i<list.length;i++){if(isVisible(list[i],eff)&&ans[list[i].id]!==undefined)eff[list[i].id]=ans[list[i].id]}for(i=from;i<list.length;i++){if(isVisible(list[i],eff))return i;}return list.length}
function keyInfo(key){if(key==="S")return {scope:"student",subj:""};var p=key.split("|");if(p[0]==="W")return {scope:"weekly",subj:p[1],round:p[2]};return {scope:"subject",subj:p[1]}}
function qText(q,subj){return String(q.text).replace(/\{subject\}/g,subj||"this subject")}
function analyse(m,key){
  var info=keyInfo(key),list=listFor(info.scope,bandOf(m.year)),eff=effOf(list,m.ans[key]||{}),R=S.rules;
  var sums={},rep=[],flags=[],r={cons:[],rep:rep,flags:flags,methods:[],rem:{student:[],parent:[]}};
  list.forEach(function(q){
    var a=eff[q.id];if(a===undefined)return;
    if(q.kind==="scale"&&q.construct)(sums[q.construct]=sums[q.construct]||[]).push(q.reverse?6-Number(a):Number(a));
    if(q.report&&(q.kind==="choice"||q.kind==="multi")){
      var arr=Array.isArray(a)?a:[a];
      var labs=arr.map(function(v){var o=q.opts.filter(function(x){return String(x.v)===String(v)})[0];return o?o.l:v});
      rep.push({q:qText(q,info.subj),a:labs.join("; ")});
    }
    if(q.flag&&q.flag.op&&condOK(q.flag,a))flags.push({type:q.flag.type||"note",msg:String(q.flag.msg).replace(/\{subject\}/g,info.subj||"a subject"),q:q.id});
    if(q.kind==="text"&&String(a).trim())flags.push({type:"note",msg:"Student note: "+String(a).trim(),q:q.id});
  });
  Object.keys(R.constructs).forEach(function(k){
    var v=sums[k];if(!v||!v.length)return;
    var avg=v.reduce(function(x,y){return x+y},0)/v.length,lvl=avg<R.thr.low?"low":avg>=R.thr.high?"high":"mid";
    r.cons.push({key:k,label:R.constructs[k].label,avg:avg,level:lvl,text:R.constructs[k][lvl]});
  });
  if(key!=="S")return r;
  function has(id,v){var a=eff[id];return Array.isArray(a)&&a.indexOf(v)>-1}
  var M=R.methods;
  function add(k,st,why){if(M[k])r.methods.push({key:k,label:M[k].label,status:st,why:why,ev:M[k].ev,tip:M[k].tip})}
  if(eff.B1!==undefined||eff.B3!==undefined){var u=has("B1","flashcards")||has("B1","pastpapers")||eff.B3==="quiz"||eff.B3==="past";add("recall",u?"using":"start",u?"Already tests themselves.":"Mostly rereads or does not check. Start with self-testing.")}
  if(eff.B2!==undefined){var sp=eff.B2==="spread"||has("B1","plan");add("spacing",sp?"using":eff.B2==="short"?"try":"start",sp?"Already spreads revision out.":eff.B2==="cram"?"Mostly cramming the night before.":"Revises in the last few days only.")}
  if(eff.B5!==undefined)add("meta",eff.B5==="why"?"using":(eff.B5==="ignore"?"start":"try"),eff.B5==="why"?"Works out why errors happen.":"Does not yet reflect on mistakes.");
  if(eff.B1!==undefined)add("interleave",has("B1","mix")?"using":"later",has("B1","mix")?"Already mixes topics.":"Add after the basics are secure.");
  if(eff.B6!==undefined)add("feynman",Number(eff.B6)>=4?"using":"try",Number(eff.B6)>=4?"Can explain without notes.":"Finds it hard to explain without notes.");
  if(eff.B7!==undefined)add("dual",eff.B7==="often"?"using":"try",eff.B7==="often"?"Often makes diagrams.":"Rarely turns notes into visuals.");
  if(eff.B8!==undefined)add("chunk",eff.B8==="split"?"using":(eff.B8==="avoid"?"start":"try"),eff.B8==="split"?"Breaks big topics down.":"Struggles when a topic feels too big.");
  if(eff.C1!==undefined&&eff.C2!==undefined&&eff.C3!==undefined){
    var hrs=(24-Number(eff.C1))+Number(eff.C2)-Number(eff.C3)/60,young=yearNum(m.year)<=8,mn=young?R.sleep.yMin:R.sleep.tMin,mx=young?R.sleep.yMax:R.sleep.tMax;
    var st=hrs<mn?"short":"ok";
    r.sleep={hrs:hrs,min:mn,max:mx,status:st,text:"Estimated sleep on school nights is about "+hrs.toFixed(1)+" hours. Guidance for this age is "+mn+" to "+mx+" hours."+(st==="short"?" That is below the range.":"")};
    add("sleep",st==="ok"?"using":"start",st==="ok"?"Sleep is within the guidance range.":"Sleep is below the guidance range.");
    if(st==="short"){r.rem.student.push("Try to bring bedtime earlier. Sleep helps memory and focus.");r.rem.parent.push("Sleep looks shorter than recommended for their age. A steadier, earlier bedtime would help.")}
    var cut=Number(eff.C1)-R.sleep.gap,al=eff.C4,w="";
    if(al==="morning")w="Best focus is in the morning: use 15 to 20 minutes of recall before school and put the hardest topic right after school. ";
    else if(al==="afternoon")w="After school (about 4pm to 6pm) is likely the best block. ";
    else if(al==="evening")w="Focus builds later: aim for a main block around 6pm to 8pm and keep mornings light. ";
    else if(al==="varies")w="Try two different time slots for two weeks and note which feels sharper. ";
    r.window="This is a rule of thumb your teacher can override. "+w+"Finish studying by about "+fmtHour(cut)+" so there is wind-down time before bed.";r.cutoff=cut;r.alert=al;
  }
  R.reminders.forEach(function(x){if(condOK({op:x.op,val:x.val},eff[x.q]))(x.aud==="parent"?r.rem.parent:r.rem.student).push(x.text)});
  var order=R.priority||[];
  r.methods.sort(function(a,b){return order.indexOf(a.key)-order.indexOf(b.key)});
  return r;
}
function statusOf(m,key){return m.done[key]?"Done":(m.ans[key]&&Object.keys(m.ans[key]).length?"In progress":"Not started")}
function flagsHTML(fl){return fl.map(function(f){return '<div class="warnbox"><strong>'+(f.type==="wellbeing"?"Suggest a teacher check-in: ":f.type==="sleep"?"Sleep: ":f.type==="caffeine"?"Caffeine: ":"Note: ")+'</strong>'+esc(f.msg)+'</div>'}).join("")}
function consHTML(cons){return cons.length?'<ul class="tight">'+cons.map(function(c){return '<li><strong>'+esc(c.label)+'</strong> <span class="chip '+(c.level==="low"?"start":c.level==="high"?"using":"try")+'">'+c.level+' ('+c.avg.toFixed(1)+')</span><br><span class="meta">'+esc(c.text)+'</span></li>'}).join("")+'</ul>':""}
function repHTML(rep){return rep.length?'<ul class="tight">'+rep.map(function(x){return '<li><span class="meta">'+esc(x.q)+'</span> '+esc(x.a)+'</li>'}).join("")+'</ul>':""}
function resultsFor(m){
  var h="";
  (m.subs||[]).forEach(function(s){
    var k="A|"+s.subject;
    h+='<h3>'+esc(s.subject)+' ('+esc(s.board)+'): '+esc(alias("A"))+' (Mindset Scan) <span class="chip">'+statusOf(m,k)+'</span></h3>';
    if(m.done[k]){var r=analyse(m,k);h+=flagsHTML(r.flags)+consHTML(r.cons)+repHTML(r.rep)}
  });
  h+='<h3>'+esc(alias("B"))+', '+esc(alias("C"))+', '+esc(alias("D"))+' (memory, body clock, habits) <span class="chip">'+statusOf(m,"S")+'</span></h3>';
  if(m.done.S){
    var r2=analyse(m,"S");
    h+=flagsHTML(r2.flags);
    if(r2.sleep)h+='<p>'+esc(r2.sleep.text)+'</p>';
    if(r2.window)h+='<p>'+esc(r2.window)+'</p>';
    var starts=r2.methods.filter(function(x){return x.status==="start"}).slice(0,3);
    if(starts.length<2)starts=starts.concat(r2.methods.filter(function(x){return x.status==="try"}).slice(0,3-starts.length));
    h+='<p><strong>Suggested starter kit (for teacher review):</strong> '+(starts.map(function(x){return esc(x.label)}).join(", ")||"none yet")+'</p>';
    h+='<ul class="tight">'+r2.methods.map(function(x){return '<li><span class="chip '+x.status+'">'+({using:"Already using",start:"Start here",try:"Try next",later:"Later"}[x.status])+'</span> <strong>'+esc(x.label)+'</strong><br><span class="meta">'+esc(x.why)+' Evidence: '+esc(x.ev)+'</span></li>'}).join("")+'</ul>';
    h+=repHTML(r2.rep);
    h+='<p><strong>Reminders for the student</strong></p><ul class="tight">'+(r2.rem.student.map(function(t){return '<li>'+esc(t)+'</li>'}).join("")||"<li>None</li>")+'</ul>';
    h+='<p><strong>Reminders for the parent</strong></p><ul class="tight">'+(r2.rem.parent.map(function(t){return '<li>'+esc(t)+'</li>'}).join("")||"<li>None</li>")+'</ul>';
  }
  return h;
}
var S={bank:defaultBank(),rules:defaultRules()};
g.DISC={S:S,analyse:analyse,listFor:listFor,effOf:effOf,nextIdx:nextIdx,isVisible:isVisible,keyInfo:keyInfo,qText:qText,bandOf:bandOf,alias:alias,statusOf:statusOf,resultsFor:resultsFor};
})(window);
