/* Discovery runner: Nova (per subject) and Orion, Vega, Lyra (study habits and body clock). */
(function(){
var D=window.DISC,S=null,M=null,key='',list=[],i=0,hist=[],saveT=null;
var SCALE=['Not like me','A little like me','Sometimes like me','Mostly like me','Very like me'];
function esc(t){return String(t==null?'':t).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function render(h){document.getElementById('app').innerHTML=h;wire()}
function ans(){M.ans=M.ans||{};return M.ans[key]=M.ans[key]||{}}
function post(extra){if(!S.consented)return Promise.resolve(false);return fetch('/api/student/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.assign({ans:M.ans},extra||{}))}).then(function(r){return r.status===200}).catch(function(){return false})}
function queue(){clearTimeout(saveT);saveT=setTimeout(post,500)}
function title(){var info=D.keyInfo(key);if(info.scope==='weekly')return D.alias('E')+' weekly check-in: '+info.subj;return info.subj?D.alias('A')+': '+info.subj:D.alias('B')+', '+D.alias('C')+' and '+D.alias('D')}
function show(){
  var q=list[i];if(!q)return finish();
  var info=D.keyInfo(key),a=ans(),cur=a[q.id],eff=D.effOf(list,a),vis=list.filter(function(x){return D.isVisible(x,eff)}).length||1;
  var done=list.slice(0,i).filter(function(x){return eff[x.id]!==undefined}).length,pct=Math.round(100*done/vis);
  var h='<p class="muted">'+esc(title())+'</p><div class="bar" role="progressbar" aria-valuenow="'+pct+'" aria-valuemin="0" aria-valuemax="100"><i style="width:'+pct+'%"></i></div><div class="card"><p class="q">'+esc(D.qText(q,info.subj))+'</p>';
  if(q.kind==='scale')h+='<div class="scale" role="group" aria-label="Choose one">'+[1,2,3,4,5].map(function(n){return '<button class="opt" aria-pressed="'+(cur===n)+'" data-v="'+n+'">'+n+'<br><small>'+SCALE[n-1]+'</small></button>'}).join('')+'</div>';
  else if(q.kind==='choice')h+='<div class="opts">'+q.opts.map(function(o,j){return '<button class="opt" aria-pressed="'+(String(cur)===String(o.v))+'" data-oi="'+j+'">'+esc(o.l)+'</button>'}).join('')+'</div>';
  else if(q.kind==='multi')h+='<p class="muted">Choose all that apply.</p><div class="opts">'+q.opts.map(function(o,j){var on=Array.isArray(cur)&&cur.indexOf(o.v)>-1;return '<button class="opt" aria-pressed="'+on+'" data-tog="'+j+'">'+(on?'✓ ':'')+esc(o.l)+'</button>'}).join('')+'</div><div class="actions"><button data-next>Next</button></div>';
  else h+='<textarea id="txt" rows="3" maxlength="300">'+esc(cur||'')+'</textarea><div class="actions"><button data-next>Next</button></div>';
  h+='</div><div class="actions"><button class="ghost" data-back'+(hist.length?'':' disabled')+'>Back</button><a href="/"><button class="ghost">Save and leave</button></a></div>';
  if(!S.consented)h+='<div class="warnbox">Your answers will not be saved yet because we are still waiting for a parent or guardian to give permission.</div>';
  render(h);
}
function advance(){hist.push(i);i=D.nextIdx(list,ans(),i+1);queue();show()}
async function finish(){
  clearTimeout(saveT);M.done=M.done||{};M.done[key]=Date.now();
  var r=D.analyse(M,key),wb=r.flags.filter(function(f){return f.type==='wellbeing'});
  var ok=await post({done:M.done,newFlags:wb.map(function(f){return {type:'wellbeing',message:f.msg}})});
  var h='<h1>Thank you</h1><div class="card"><p>Your answers help your teacher build a plan that suits you. There are no right or wrong answers.</p>';
  if(wb.length)h+='<div class="warnbox">'+esc(D.S.rules.msgWellbeing)+'</div>';
  if(key==='S'&&r.rem.student.length)h+='<h2>Your study tips</h2><ul>'+r.rem.student.map(function(t){return '<li>'+esc(t)+'</li>'}).join('')+'</ul>';
  if(!ok)h+='<p class="muted">Not saved yet: we are waiting for permission from a parent or guardian.</p>';
  render(h+'<div class="actions"><a href="/"><button>Home</button></a></div></div>');
}
function wire(){
  var q=list[i];
  document.querySelectorAll('[data-v]').forEach(function(b){b.onclick=function(){ans()[q.id]=Number(b.getAttribute('data-v'));advance()}});
  document.querySelectorAll('[data-oi]').forEach(function(b){b.onclick=function(){ans()[q.id]=q.opts[Number(b.getAttribute('data-oi'))].v;advance()}});
  document.querySelectorAll('[data-tog]').forEach(function(b){b.onclick=function(){var a=ans(),v=q.opts[Number(b.getAttribute('data-tog'))].v,cur=Array.isArray(a[q.id])?a[q.id].slice():[],k=cur.indexOf(v);if(k>-1)cur.splice(k,1);else cur.push(v);a[q.id]=cur;show()}});
  var n=document.querySelector('[data-next]');if(n)n.onclick=function(){var t=document.getElementById('txt');if(t){var v=t.value.trim();if(v)ans()[q.id]=v;else delete ans()[q.id]}advance()};
  var bk=document.querySelector('[data-back]');if(bk)bk.onclick=function(){if(hist.length){i=hist.pop();show()}};
}
async function load(){
  var r=await fetch('/api/state');if(r.status===401){location.href='/login.html';return}
  S=await r.json();M=S.member;key=decodeURIComponent((location.search.match(/key=([^&]+)/)||[])[1]||'');
  if(!M||S.me.role!=='student'||!(key==='S'||/^[AW]\|/.test(key))){render('<p class="muted">Nothing to show. <a href="/">Home</a></p>');return}
  list=D.listFor(D.keyInfo(key).scope,D.bandOf(M.year));
  var a=ans(),first=0;if(!(M.done&&M.done[key])){first=D.nextIdx(list,{},0);while(first<list.length&&a[list[first].id]!==undefined){hist.push(first);first=D.nextIdx(list,a,first+1)}}
  i=first<list.length?first:D.nextIdx(list,{},0);
  render('<h1>'+esc(title())+'</h1><div class="card"><p>'+(key==='S'?'Some questions about how you revise, how you sleep and your study habits.':/^W/.test(key)?'Five quick questions about your week in '+esc(D.keyInfo(key).subj)+'.':'Some questions about how you feel about '+esc(D.keyInfo(key).subj)+'.')+(/^W/.test(key)?' It takes about 1 minute.':' It takes about 5 minutes.')+' <strong>There are no right or wrong answers</strong>, and it is not marked.</p><p class="muted">Your teacher sees your answers so they can help you. If you tell us you feel very stressed or overwhelmed, a safe adult will check in with you. <a href="/privacy.html">Privacy</a></p><div class="actions"><button data-go>'+((M.done&&M.done[key])?'Do it again':(Object.keys(a).length?'Carry on':'Start'))+'</button></div></div>');
  document.querySelector('[data-go]').onclick=show;
}
load();
})();
