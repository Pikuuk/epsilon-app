function esc(t){return String(t==null?'':t).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
async function get(){var r=await fetch('/api/state');if(r.status===401){location.href='/login.html';return null;}return r.json();}
async function act(data){var r=await fetch('/api/admin/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});return{status:r.status,body:await r.json().catch(function(){return{}})};}
var S=null,flash='';
function setFlash(m){flash=m;}
async function refresh(){S=await get();if(S)render();}
function render(){
  var m=S.me;
  document.getElementById('whoami').innerHTML=esc(m.name)+' · '+esc(m.role)+' · <a href="#" id="lo" style="color:#cfe">Sign out</a>';
  document.getElementById('lo').onclick=async function(e){e.preventDefault();await fetch('/api/logout',{method:'POST'});location.href='/login.html';};
  var h=flash?'<div class="flash">'+esc(flash)+'</div>':'';flash='';
  if(m.role==='super')h+=superView();
  else if(m.role==='teacher')h+=teacherView();
  else if(m.role==='student')h+=studentView();
  else if(m.role==='parent')h+=parentView();
  document.getElementById('app').innerHTML=h;
  wire();
}
function superView(){
  var pend=S.requests.filter(function(r){return r.status==='pending'});
  var openFlags=(S.safeguard||[]).filter(function(s){return !s.handled});
  var h='<h1>Control room</h1>';
  if(openFlags.length)h+='<div class="warnbox"><strong>'+openFlags.length+' safeguarding flag(s) need attention.</strong> Follow your safeguarding process and contact '+esc(S.settings.dsl_name)+'.</div>';
  h+='<div class="card"><h2 style="margin:0 0 .4rem">Switchboard</h2><label style="font-weight:400"><input type="checkbox" data-flag="registration_open" '+(S.flags.registration_open?'checked':'')+'> Allow new access requests</label><p class="muted">Turn parts of the system on or off without breaking the rest.</p></div>';
  h+='<h2>Requests waiting ('+pend.length+')</h2>';
  if(!pend.length)h+='<p class="muted">None.</p>';
  pend.forEach(function(r){
    h+='<div class="card" data-req="'+r.id+'"><div class="row"><strong>'+esc(r.name)+'</strong><span class="chip warn">waiting</span></div><div class="muted">'+(r.role==='student'?'Student, '+esc(r.year):'Parent/guardian')+' · '+esc(r.email)+'</div><label>Assign teacher</label><select data-teacher><option value="">Choose…</option>'+S.users.filter(function(u){return u.role==='teacher'}).map(function(u){return '<option value="'+u.id+'">'+esc(u.name)+'</option>'}).join('')+'<option value="'+S.me.id+'">Me (super user)</option></select>';
    if(r.role==='parent')h+='<label>Link to child</label>'+childSelect('',true);
    if(r.role==='student')h+='<label>Subjects</label><div>'+['Maths','English','Biology','Chemistry','Physics'].map(function(s){return '<label style="display:inline-block;font-weight:400;margin-right:1rem"><input type="checkbox" data-subj value="'+s+'"> '+s+'</label>'}).join('')+'</div>';
    h+='<div class="actions"><button class="ok" data-approve="'+r.id+'">Approve</button><button class="bad" data-reject="'+r.id+'">Reject</button></div></div>';
  });
  h+='<h2>People</h2>';
  if(!S.members.length)h+='<p class="muted">No approved people yet.</p>';
  S.members.forEach(function(mm){
    var consented=(S.consents||[]).some(function(c){return c.studentId===mm.id});
    h+='<div class="card"><div class="row"><strong>'+esc(mm.name)+'</strong><span class="chip '+(mm.status==='revoked'?'bad':'ok')+'">'+(mm.status==='revoked'?'paused':'active')+'</span></div><div class="muted">'+(mm.role==='student'?'Student, '+esc(mm.year):'Parent')+' · teacher: '+esc(teacherName(mm.teacherId))+'</div>'+(mm.role==='student'?('<div>'+(consented?'<span class="chip ok">parental consent on file</span>':'<span class="chip bad">no consent yet — student is blocked from saving work</span>')+'</div>'):'')+(mm.role==='student'?progressLine(mm)+planBlock(mm)+attBlock(mm):'<div class="muted">Linked child: '+esc(mm.childId?memberName(mm.childId):'none')+'</div>'+childSelect(mm.childId,false,mm.id))+'<div class="actions">'+(mm.role==='student'?'<button class="ghost" data-plan="'+mm.id+'">'+(DRAFT[mm.id]?'Close plan':'Plan')+'</button><button class="ghost" data-ses="'+mm.id+'">'+(SES[mm.id]?'Close sessions':'Sessions')+'</button>':'')+(mm.role==='student'&&!consented?'<button data-consent="'+mm.id+'">Record parental consent</button>':'')+(mm.status==='revoked'?'<button class="ok" data-restore="'+mm.id+'">Restore access</button>':'<button class="bad" data-revoke="'+mm.id+'">Pause access</button>')+'</div></div>';
  });
  h+=attendanceCard()+markingCard();
  h+='<h2>Wellbeing flags</h2>';
  if(!(S.safeguard||[]).length)h+='<p class="muted">None.</p>';
  (S.safeguard||[]).slice().reverse().forEach(function(s,i){var idx=S.safeguard.length-1-i;h+='<div class="card"><div class="row"><strong>'+esc(memberName(s.studentId))+'</strong><span class="chip '+(s.handled?'ok':'bad')+'">'+(s.handled?'handled':'needs attention')+'</span></div><p>'+esc(s.message)+'</p>'+(s.handled?'':'<div class="actions"><button data-flag-idx="'+idx+'">Mark handled</button></div>')+'</div>';});
  h+=teachersCard()+bankCard();
  return h;
}

var TOPIC_NAMES={neg:'Negative numbers',frac:'Fractions',pct:'Percentages',alg:'Algebra'};
function progressLine(m){
  var dl=discLine(m);
  var bl=(m.base&&m.base.Maths&&m.base.Maths.topics)?'<div class="muted"><strong>Rigel check:</strong> '+Object.keys(m.base.Maths.topics).map(function(k){var t=m.base.Maths.topics[k];return esc(t.name)+' L'+t.secure+'/'+t.max}).join(', ')+'</div>':'<div class="muted"><strong>Rigel check:</strong> not done yet</div>';
  var lad=m.lad||{},parts=[];
  Object.keys(lad).forEach(function(t){var lv=lad[t]||{},passed=Object.keys(lv).filter(function(n){return lv[n]&&lv[n].passed}).map(Number).sort(function(a,b){return a-b});
    var best=Object.keys(lv).map(function(n){return 'L'+n+' '+((lv[n]&&lv[n].best)||0)+'/12'}).join(', ');
    if(Object.keys(lv).length)parts.push('<div class="muted"><strong>'+esc(TOPIC_NAMES[t]||t)+':</strong> '+(passed.length?'passed up to level '+passed[passed.length-1]:'no level passed yet')+' ('+esc(best)+')</div>');});
  return '<div style="margin-top:.4rem">'+dl+bl+'<div class="muted"><strong>Practice levels</strong></div>'+(parts.length?parts.join(''):'<div class="muted">Not started yet.</div>')+'</div>';
}
function teachersCard(){
  var ts=(S.users||[]).filter(function(u){return u.role==='teacher'});
  return '<h2>Teachers</h2><div class="card">'+(ts.length?ts.map(function(u){return '<div>'+esc(u.name)+' <span class="muted">'+esc(u.email)+'</span></div>'}).join(''):'<p class="muted">No teachers yet. You can act as the teacher yourself.</p>')+
  '<label>Teacher name</label><input id="tname"><label>Teacher email</label><input id="temail" type="email"><div class="actions"><button data-addteacher>Add teacher</button></div></div>';
}
function bankCard(){
  var all=(S.allItems||[]).filter(function(x){return x.status==='approved'});
  var lev=all.filter(function(x){return x.ladder}),q=all.length-lev.length,byT={};
  lev.forEach(function(x){var t=x.ladder.topic;byT[t]=byT[t]||{};byT[t][x.ladder.level]=1;});
  var rows=Object.keys(byT).map(function(t){return '<div>'+esc(TOPIC_NAMES[t]||t)+': '+Object.keys(byT[t]).length+' levels</div>'}).join('');
  return '<h2>Question bank</h2><div class="card">'+(all.length?'<p><strong>'+all.length+' approved items</strong> ('+q+' questions, '+lev.length+' level templates)</p>'+rows:'<p class="muted">Empty. Students see no practice until you load the questions.</p>')+
  '<div class="actions"><button data-importbuiltin>'+(all.length?'Reload':'Load')+' Year 7 Maths questions</button> <a href="/practice.html"><button class="ghost">Open practice (students)</button></a></div><p class="muted">Loading replaces the current bank with the built-in Year 7 Maths set (41 questions, 24 levels).</p></div>';
}

var DRAFT={},SPEC={neg:'negative',frac:'fraction',pct:'percentage',alg:'algebra'};
function hs(x){var h=2166136261;x=String(x);for(var i=0;i<x.length;i++){h^=x.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function tid(){return 't'+Math.random().toString(36).slice(2,8)}
function member(id){return (S.members||[]).filter(function(x){return x.id===id})[0]}
function taskDone(m,t){if(t.kind==='level'){var l=m.lad&&m.lad[t.topic]&&m.lad[t.topic][t.level];if(l&&l.passed)return true}return !!(m.done&&m.done[t.id])}
function suggestPlan(m){
  var tasks=[],base=m.base&&m.base.Maths&&m.base.Maths.topics;
  var tps=base?Object.keys(base).sort(function(a,b){return (base[a].secure/(base[a].max||1))-(base[b].secure/(base[b].max||1))}):[];
  if(!tps.length)tasks.push({id:tid(),kind:'note',title:'Do the Rigel check',text:'On your home page press Start Rigel check. It finds your starting levels.'});
  tps.slice(0,2).forEach(function(t){var b=base[t];if(b.secure>=b.max)return;var L=Math.min(b.max,b.secure+1);tasks.push({id:tid(),kind:'level',topic:t,level:L,title:'Practice: '+(TOPIC_NAMES[t]||t)+' level '+L})});
  var pool=(S.allItems||S.items||[]).filter(function(x){return x.status==='approved'&&!x.ladder});
  var seen={};(m.attempts||[]).forEach(function(a){(a.items||[]).forEach(function(i){seen[i.qid]=1})});
  var weak=tps.slice(0,2).map(function(t){return SPEC[t]}),seed=m.id+new Date().toISOString().slice(0,10);
  function sc(x){var sp=String(x.spec||'').toLowerCase();return (weak.some(function(w){return sp.indexOf(w)>-1})?0:2)+(seen[x.id]?1:0)}
  pool.sort(function(a,b){return sc(a)-sc(b)||hs(seed+a.id)-hs(seed+b.id)});
  var q=pool.slice(0,5).map(function(x){return x.id});
  if(q.length)tasks.push({id:tid(),kind:'questions',title:q.length+' mixed questions with working',qids:q});
  habitTasks(m).forEach(function(t){tasks.push(t)});
  if(hasDisc()&&!(m.done&&m.done.S))tasks.push({id:tid(),kind:'note',title:'Answer the Discovery questions',text:'On your home page, open Discovery. It helps your teacher choose study methods that suit you.'});
  return {tasks:tasks};
}
function planBlock(m){
  var p=m.plan,h='<div style="margin-top:.4rem">';
  if(p&&p.status==='published'&&p.tasks){var dn=p.tasks.filter(function(t){return taskDone(m,t)}).length;h+='<div class="muted"><strong>Plan:</strong> '+dn+' of '+p.tasks.length+' tasks done (published '+new Date(p.publishedAt||Date.now()).toLocaleDateString('en-GB')+')</div>'}
  else h+='<div class="muted"><strong>Plan:</strong> none published</div>';
  var d=DRAFT[m.id];
  if(d)h+='<div class="card" style="background:var(--bg);margin-top:.5rem"><strong>Plan for '+esc(m.name)+'</strong>'+(d.tasks.length?'<ol>'+d.tasks.map(function(t,i){return '<li>'+esc(t.title)+(t.text?' <span class="muted">('+esc(t.text)+')</span>':'')+' <button class="ghost" data-pdel="'+m.id+':'+i+'">Remove</button></li>'}).join('')+'</ol>':'<p class="muted">No tasks.</p>')+
    '<label for="pn-'+m.id+'">Add an instruction task (for example a video or a page to read)</label><input id="pn-'+m.id+'" placeholder="What should the student do?"><div class="actions"><button class="ghost" data-pnote="'+m.id+'">Add task</button><button class="ghost" data-psuggest="'+m.id+'">Suggest again</button><button class="ok" data-ppublish="'+m.id+'">Publish plan</button></div><p class="muted">Suggested from the Rigel check (weakest topics), the question bank and Discovery (study habits to start). Publishing replaces the current plan.</p></div>';
  return h+'</div>';
}
function markingCard(){
  var rows=[];(S.members||[]).forEach(function(m){(m.attempts||[]).forEach(function(a){if(!a.reviewed)rows.push({m:m,a:a})})});
  var h='<h2>Marking ('+rows.length+' to check)</h2>';
  if(!rows.length)return h+'<p class="muted">Nothing to check. Submitted question tasks appear here.</p>';
  rows.slice(-10).reverse().forEach(function(r){var a=r.a;
    h+='<div class="card"><div class="row"><strong>'+esc(r.m.name)+': '+esc(a.title)+'</strong><span class="chip">'+a.score+'/'+a.of+' auto-marked</span></div>';
    a.items.forEach(function(it,i){if(it.review){h+='<div class="muted">'+(i+1)+'. checked ('+esc(it.review.verdict)+')</div>';return}
      var k=r.m.id+'|'+a.id+'|'+i;
      h+='<div style="border-top:1px solid var(--line);margin-top:.5rem;padding-top:.5rem"><div>'+(i+1)+'. '+esc(it.stem)+'</div><div class="muted">Student: <strong>'+esc(it.shown||'(blank)')+'</strong> · correct: '+esc(it.answer)+' · auto-mark: '+(it.correct?'✓':'✗')+'</div>'+(it.workings?'<div class="muted">Working: '+esc(it.workings)+'</div>':'<div class="muted">No working shown.</div>')+
      '<input id="rc-'+a.id+'-'+i+'" placeholder="Comment for the student (optional)"><div class="actions"><button class="ghost" data-review="'+k+'|agree">Agree</button><button class="ghost" data-review="'+k+'|correct">Mark correct</button><button class="ghost" data-review="'+k+'|wrong">Mark wrong</button></div></div>'});
    h+='<div class="actions"><button data-reviewall="'+r.m.id+'|'+a.id+'">Agree with all the rest</button></div></div>'});
  return h;
}
function studentPlan(m){
  var p=m.plan;
  if(!p||p.status!=='published'||!(p.tasks||[]).length)return '<div class="card"><h2 style="margin-top:0">Your plan this week</h2><p class="muted">Your teacher has not set a plan yet.</p></div>';
  var h='<div class="card"><h2 style="margin-top:0">Your plan this week</h2><ol>';
  p.tasks.forEach(function(t){var d=taskDone(m,t),last=(m.attempts||[]).filter(function(a){return a.taskId===t.id}).pop();
    h+='<li style="margin:.6rem 0">'+(d?'✅ ':'')+'<strong>'+esc(t.title)+'</strong>'+(t.text?'<div class="muted">'+esc(t.text)+'</div>':'');
    if(t.kind==='level')h+='<div><a href="/practice.html"><button class="ghost">Go to practice</button></a> <span class="muted">Pass level '+t.level+' to complete this.</span></div>';
    else if(t.kind==='questions')h+='<div><a href="/questions.html?task='+encodeURIComponent(t.id)+'"><button class="ghost">'+(last?'See results':'Start')+'</button></a>'+(last?' <span class="muted">'+(last.finalScore!=null?last.finalScore:last.score)+'/'+last.of+(last.reviewed?' · checked by your teacher':'')+'</span>':'')+'</div>';
    else if(!d)h+='<div><button class="ghost" data-sdone="'+t.id+'">Mark as done</button></div>';
    h+='</li>'});
  return h+'</ol></div>';
}

var SES={},DAYS=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
var ST={attended:['ok','attended'],missed:['bad','missed'],pending:['warn','explanation sent'],excused:['ok','excused']};
function chip(st){var x=ST[st]||['',''+st];return '<span class="chip '+x[0]+'">'+esc(x[1])+'</span>'}
function childSelect(cur,forApproval,parentId){var kids=(S.members||[]).filter(function(x){return x.role==='student'});
  return '<select data-child'+(parentId?'="'+parentId+'"':'')+'><option value="">None</option>'+kids.map(function(k){return '<option value="'+k.id+'"'+(k.id===cur?' selected':'')+'>'+esc(k.name)+' ('+esc(k.year)+')</option>'}).join('')+'</select>'+(parentId?' <button class="ghost" data-linkchild="'+parentId+'">Save link</button>':'')}
function sesText(x){return DAYS[x.day].slice(0,3)+' '+x.time+' ('+x.mins+' min)'}
function recent(m,n){return (m.att||[]).slice().sort(function(a,b){return b.start-a.start}).slice(0,n)}
function missRun(m){var k=0;recent(m,50).some(function(r){if(r.start<(m.streakFrom||0))return true;if(r.status==='pending')return false;if(r.status==='missed'){k++;return false}return true});return k}
function attBlock(m){
  var ses=m.sessions||[],h='<div style="margin-top:.4rem"><div class="muted"><strong>Sessions:</strong> '+(ses.length?ses.map(sesText).join(', '):'none set')+(ses.length?' · missed in a row: '+missRun(m):'')+'</div>';
  var rc=recent(m,3);if(rc.length)h+='<div class="muted">Recent: '+rc.map(function(r){return esc(r.date)+' '+esc(r.time)+' '+chip(r.status)}).join(' ')+'</div>';
  var d=SES[m.id];
  if(d){h+='<div class="card" style="background:var(--bg);margin-top:.5rem"><strong>Weekly sessions for '+esc(m.name)+'</strong> <span class="muted">(UK time)</span>'+(d.length?'<ul>'+d.map(function(x,i){return '<li>'+esc(sesText(x))+' <button class="ghost" data-sesdel="'+m.id+':'+i+'">Remove</button></li>'}).join('')+'</ul>':'<p class="muted">No sessions yet.</p>')+
    '<div class="row" style="justify-content:flex-start"><select id="sd-'+m.id+'">'+DAYS.map(function(x,i){return '<option value="'+i+'"'+(i===1?' selected':'')+'>'+x+'</option>'}).join('')+'</select> <input id="st-'+m.id+'" type="time" value="17:00" style="max-width:8rem"> <select id="sm-'+m.id+'"><option>30</option><option selected>60</option><option>90</option></select> min <button class="ghost" data-sesadd="'+m.id+'">Add</button></div>'+
    '<div class="actions"><button class="ok" data-sessave="'+m.id+'">Save sessions</button></div><p class="muted">If the student has not signed in by 15 minutes after the start, the session is recorded as missed and the parent is alerted. 3 misses in a row pause access.</p></div>'}
  return h+'</div>';
}
function attendanceCard(){
  var rows=[];(S.members||[]).filter(function(m){return m.role==='student'}).forEach(function(m){recent(m,10).forEach(function(r){if(r.status==='pending'||(r.status==='missed'&&Date.now()-r.start<8*864e5))rows.push({m:m,r:r})})});
  var h='<h2>Attendance ('+rows.filter(function(x){return x.r.status==='pending'}).length+' explanations to decide)</h2>';
  if(!rows.length)return h+'<p class="muted">No recent missed sessions.</p>';
  rows.forEach(function(x){var k=x.m.id+'|'+x.r.id;
    h+='<div class="card"><div class="row"><strong>'+esc(x.m.name)+': '+esc(x.r.date)+' '+esc(x.r.time)+'</strong>'+chip(x.r.status)+'</div>'+(x.r.explanation?'<p>Parent says: “'+esc(x.r.explanation)+'”</p>':'')+
    '<div class="actions"><button class="ok" data-att="'+k+'|excuse">Excuse</button>'+(x.r.status==='pending'?'<button class="bad" data-att="'+k+'|reject">Do not accept</button>':'')+'<button class="ghost" data-att="'+k+'|attended">Actually attended</button></div></div>'});
  return h;
}
function sessionsCard(m,isParent){
  var ses=m.sessions||[],h='<div class="card"><h2 style="margin-top:0">'+(isParent?'Sessions and attendance':'Your sessions')+'</h2>';
  h+=ses.length?'<p>'+ses.map(sesText).join(' · ')+' <span class="muted">(UK time)</span></p>':'<p class="muted">No sessions set yet.</p>';
  var rc=recent(m,8);
  if(rc.length)h+='<ul>'+rc.map(function(r){var s='<li>'+esc(r.date)+' '+esc(r.time)+' '+chip(r.status);
    if(isParent&&r.status==='missed')s+='<div><label for="ex-'+r.id+'" class="muted">Explain why (optional). This pauses the missed-session count while the school looks at it.</label><textarea id="ex-'+r.id+'" rows="2"></textarea><button class="ghost" data-explain="'+r.id+'">Send explanation</button></div>';
    if(r.explanation)s+='<div class="muted">Your explanation: '+esc(r.explanation)+'</div>';return s+'</li>'}).join('')+'</ul>';
  return h+'</div>';
}
function alertsCard(m){var a=(m.alerts||[]).slice(-5).reverse();if(!a.length)return '';return '<div class="card"><h2 style="margin-top:0">Messages</h2><ul>'+a.map(function(x){return '<li><span class="muted">'+new Date(x.at).toLocaleDateString('en-GB')+'</span> '+esc(x.text)+'</li>'}).join('')+'</ul></div>'}

var DISCOPEN={};
function hasDisc(){return typeof DISC!=='undefined'}
function discKeys(m){return (m.subs||[]).map(function(s){return 'A|'+s.subject}).concat(['S'])}
function discName(k){return k==='S'?DISC.alias('B')+', '+DISC.alias('C')+' and '+DISC.alias('D'):DISC.alias('A')+': '+k.split('|')[1]}
function discoveryCard(m){
  if(!hasDisc())return '';
  var h='<div class="card"><h2 style="margin-top:0">Discovery</h2><p class="muted">Short questions about how you learn, sleep and study. No right or wrong answers. They help your teacher plan for you.</p><ul>';
  discKeys(m).forEach(function(k){var done=m.done&&m.done[k],started=m.ans&&m.ans[k]&&Object.keys(m.ans[k]).length;
    h+='<li style="margin:.4rem 0">'+(done?'✅ ':'')+'<strong>'+esc(discName(k))+'</strong> <a href="/discovery.html?key='+encodeURIComponent(k)+'"><button class="ghost">'+(done?'Redo':started?'Carry on':'Start')+'</button></a></li>'});
  return h+'</ul></div>';
}
function discLine(m){
  if(!hasDisc()||!S.me||(S.me.role!=='super'&&S.me.role!=='teacher'))return '';
  var ks=discKeys(m),d=ks.filter(function(k){return m.done&&m.done[k]}).length,h='<div class="muted"><strong>Discovery:</strong> '+d+' of '+ks.length+' done';
  if(m.done&&m.done.S){var r=DISC.analyse(m,'S');if(r.sleep)h+=' · sleep '+r.sleep.hrs.toFixed(1)+'h'+(r.sleep.status==='short'?' (short)':'');}
  var wb=0;ks.forEach(function(k){if(m.done&&m.done[k])wb+=DISC.analyse(m,k).flags.filter(function(f){return f.type==='wellbeing'}).length});
  if(wb)h+=' · <span class="chip bad">wellbeing flag</span>';
  h+=' <button class="ghost" data-disc="'+m.id+'">'+(DISCOPEN[m.id]?'Hide details':'Details')+'</button></div>';
  h+=weeklyLine(m);
  if(DISCOPEN[m.id])h+='<div class="card" style="background:var(--bg);margin-top:.5rem">'+DISC.resultsFor(m)+'<p class="muted">Suggestions only. You decide what goes in the plan.</p></div>';
  return h;
}
function parentTips(c){
  if(!hasDisc()||!(c.done&&c.done.S))return '';
  var r=DISC.analyse(c,'S');if(!r.rem.parent.length)return '';
  return '<div class="card"><h2 style="margin-top:0">Ways to help at home</h2><ul>'+r.rem.parent.map(function(t){return '<li>'+esc(t)+'</li>'}).join('')+'</ul></div>';
}

function weekKeys(m){var p=m.plan;if(!p||p.status!=='published')return [];return (m.subs||[]).map(function(s){return 'W|'+s.subject+'|'+(p.publishedAt||0)})}
function weeklyCard(m){
  if(!hasDisc())return '';var ks=weekKeys(m);if(!ks.length)return '';
  return '<div class="card"><h2 style="margin-top:0">'+esc(DISC.alias('E'))+' weekly check-in</h2><p class="muted">One minute: tell your teacher how this week went.</p><ul>'+ks.map(function(k){var done=m.done&&m.done[k];
    return '<li style="margin:.4rem 0">'+(done?'✅ ':'')+'<strong>'+esc(k.split('|')[1])+'</strong> <a href="/discovery.html?key='+encodeURIComponent(k)+'"><button class="ghost">'+(done?'Change answers':'Start')+'</button></a></li>'}).join('')+'</ul></div>';
}
function weeklyLine(m){
  var ks=weekKeys(m);if(!ks.length)return '';
  var LBL={UN:'understood',RC:'recall',CF:'confidence'};
  return ks.map(function(k){var subj=k.split('|')[1];
    if(!(m.done&&m.done[k]))return '<div class="muted"><strong>'+esc(DISC.alias('E'))+' ('+esc(subj)+'):</strong> not done this week</div>';
    var r=DISC.analyse(m,k),c=r.cons.filter(function(x){return LBL[x.key]}).map(function(x){return LBL[x.key]+' '+x.level}).join(', ');
    var hard=r.rep.map(function(x){return x.a}).join('; '),wb=r.flags.some(function(f){return f.type==='wellbeing'});
    return '<div class="muted"><strong>'+esc(DISC.alias('E'))+' ('+esc(subj)+'):</strong> '+esc(c)+(hard?' · hardest: '+esc(hard):'')+(wb?' <span class="chip bad">felt very stressful</span>':'')+'</div>'}).join('');
}
function habitTasks(m){
  if(!hasDisc()||!(m.done&&m.done.S))return [];
  var r=DISC.analyse(m,'S'),pick=r.methods.filter(function(x){return x.status==='start'&&x.key!=='sleep'});
  if(pick.length<2)pick=pick.concat(r.methods.filter(function(x){return x.status==='try'&&x.key!=='sleep'}));
  return pick.slice(0,2).map(function(x){return {id:tid(),kind:'note',title:'Study habit: '+x.label,text:x.tip}});
}
function teacherView(){
  var pend=S.requests.filter(function(r){return r.status==='pending'});
  var h='<h1>Teacher desk</h1>';
  var flags=(S.safeguard||[]).filter(function(s){return !s.handled});
  if(flags.length)h+='<div class="warnbox"><strong>'+flags.length+' wellbeing flag(s) for your students.</strong> Follow your safeguarding process.</div>';
  h+='<h2>Requests assigned to you ('+pend.length+')</h2>';
  if(!pend.length)h+='<p class="muted">None. The super user assigns requests to teachers.</p>';
  pend.forEach(function(r){h+='<div class="card"><div class="row"><strong>'+esc(r.name)+'</strong></div><div class="muted">'+esc(r.email)+'</div><div class="actions"><button class="ok" data-approve="'+r.id+'">Approve</button><button class="bad" data-reject="'+r.id+'">Reject</button></div></div>';});
  h+='<h2>Your students</h2>';
  if(!S.members.length)h+='<p class="muted">None yet.</p>';
  S.members.forEach(function(m){h+='<div class="card"><strong>'+esc(m.name)+'</strong> <span class="muted">'+esc(m.year)+'</span>'+progressLine(m)+planBlock(m)+attBlock(m)+'<div class="actions"><button class="ghost" data-plan="'+m.id+'">'+(DRAFT[m.id]?'Close plan':'Plan')+'</button><button class="ghost" data-ses="'+m.id+'">'+(SES[m.id]?'Close sessions':'Sessions')+'</button></div></div>';});
  h+=attendanceCard()+markingCard();
  h+='<h2>Wellbeing flags</h2>'+((S.safeguard||[]).length?'':'<p class="muted">None.</p>');
  (S.safeguard||[]).slice().reverse().forEach(function(s,i){var idx=S.safeguard.length-1-i;h+='<div class="card"><p>'+esc(s.message)+'</p>'+(s.handled?'<span class="chip ok">handled</span>':'<div class="actions"><button data-flag-idx="'+idx+'">Mark handled</button></div>')+'</div>';});
  return h;
}
function studentView(){
  var m=S.member;
  if(!m)return '<h1>Welcome</h1><p>Your account is being set up. Please check back soon.</p>';
  if(m.status==='revoked')return '<h1>Access paused</h1><p>'+(m.pausedFor==='attendance'?'Your access is paused after 3 missed sessions in a row. Please ask a parent or guardian to contact Epsilon Academy.':'Please contact Epsilon Academy.')+'</p>'+alertsCard(m);
  var h='<h1>Hello, '+esc(m.name)+'</h1>';
  if(!S.consented)h+='<div class="warnbox">Your learning is not switched on yet because we still need a parent or guardian to give permission. You can look around, but your answers will not be saved until then.</div>';
  h+='<p class="muted">'+esc(m.year)+'</p><div class="card"><h2 style="margin-top:0">Your subjects</h2>'+((m.subs||[]).map(function(s){return '<span class="chip">'+esc(s.subject)+' ('+esc(s.board)+')</span>'}).join('')||'<span class="muted">No subjects yet.</span>')+'<div class="actions"><a href="/baseline.html"><button>'+((m.base&&m.base.Maths)?'Redo Rigel check':'Start Rigel check')+'</button></a> <a href="/practice.html"><button class="ghost">Open practice levels</button></a></div><p class="muted">'+((m.base&&m.base.Maths)?'Rigel check done. Practice from your starting levels.':'New here? Do the short Rigel check first so you start at the right level.')+'</p></div>'+studentPlan(m)+weeklyCard(m)+discoveryCard(m)+sessionsCard(m,false)+alertsCard(m);
  return h;
}
function parentView(){
  var me=S.member,c=S.child;
  var h='<h1>Welcome'+(me?', '+esc(me.name):'')+'</h1>'+(me?alertsCard(me):'');
  if(!c)return h+'<p>Your account is not linked to a child yet. The Epsilon team will link it soon.</p>';
  var p=c.plan,pd=(p&&p.tasks)?p.tasks.filter(function(t){return taskDone(c,t)}).length:0;
  h+='<div class="card"><h2 style="margin-top:0">'+esc(c.name)+'</h2><p class="muted">'+esc(c.year)+(c.status==='revoked'?' · <strong>access paused</strong>'+(c.pausedFor==='attendance'?' (3 missed sessions in a row)':''):'')+'</p>'+
    '<div class="muted"><strong>This week\'s plan:</strong> '+((p&&p.tasks&&p.tasks.length)?pd+' of '+p.tasks.length+' tasks done':'not set yet')+'</div>'+progressLine(c)+'</div>';
  h+=parentTips(c)+sessionsCard(c,true);
  return h;
}
function teacherName(id){var u=(S.users||[]).filter(function(x){return x.id===id})[0];if(u)return u.name;if(id===S.me.id)return S.me.name+' (you)';return 'a teacher';}
function memberName(id){var m=(S.members||[]).filter(function(x){return x.id===id})[0];return m?m.name:'a student';}
function wire(){
  document.querySelectorAll('[data-disc]').forEach(function(b){b.onclick=function(){var id=b.getAttribute('data-disc');DISCOPEN[id]=!DISCOPEN[id];render();};});
  document.querySelectorAll('[data-ses]').forEach(function(b){b.onclick=function(){var id=b.getAttribute('data-ses');if(SES[id])delete SES[id];else SES[id]=JSON.parse(JSON.stringify(member(id).sessions||[]));render();};});
  document.querySelectorAll('[data-sesadd]').forEach(function(b){b.onclick=function(){var id=b.getAttribute('data-sesadd'),t=document.getElementById('st-'+id).value;if(!/^\d{1,2}:\d{2}$/.test(t))return alert('Choose a time.');SES[id].push({day:Number(document.getElementById('sd-'+id).value),time:t,mins:Number(document.getElementById('sm-'+id).value)});render();};});
  document.querySelectorAll('[data-sesdel]').forEach(function(b){b.onclick=function(){var p=b.getAttribute('data-sesdel').split(':');SES[p[0]].splice(Number(p[1]),1);render();};});
  document.querySelectorAll('[data-sessave]').forEach(function(b){b.onclick=async function(){var id=b.getAttribute('data-sessave');var r=await act({type:'set_sessions',id:id,sessions:SES[id]});if(r.status!==200)return alert(r.body.error||'Could not save.');delete SES[id];setFlash('Sessions saved.');refresh();};});
  document.querySelectorAll('[data-att]').forEach(function(b){b.onclick=async function(){var p=b.getAttribute('data-att').split('|');var r=await act({type:'attendance',studentId:p[0],attId:p[1],decision:p[2]});if(r.status!==200)return alert(r.body.error||'Could not save.');setFlash('Attendance updated.');refresh();};});
  document.querySelectorAll('[data-linkchild]').forEach(function(b){b.onclick=async function(){var id=b.getAttribute('data-linkchild'),sel=document.querySelector('[data-child="'+id+'"]');var r=await act({type:'set_subjects',id:id,childId:sel?sel.value:''});if(r.status!==200)return alert(r.body.error||'Could not save.');setFlash('Parent linked.');refresh();};});
  document.querySelectorAll('[data-explain]').forEach(function(b){b.onclick=async function(){var id=b.getAttribute('data-explain'),t=document.getElementById('ex-'+id).value.trim();if(!t)return alert('Please write a short explanation.');var r=await fetch('/api/parent/explain',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({attId:id,text:t})});var j=await r.json().catch(function(){return{}});if(r.status!==200)return alert(j.error||'Could not send.');setFlash('Explanation sent. Thank you.');refresh();};});

  document.querySelectorAll('[data-plan]').forEach(function(b){b.onclick=function(){var id=b.getAttribute('data-plan'),m=member(id);if(DRAFT[id])delete DRAFT[id];else DRAFT[id]=(m.plan&&m.plan.tasks&&m.plan.tasks.length)?{tasks:JSON.parse(JSON.stringify(m.plan.tasks))}:suggestPlan(m);render();};});
  document.querySelectorAll('[data-psuggest]').forEach(function(b){b.onclick=function(){var id=b.getAttribute('data-psuggest');DRAFT[id]=suggestPlan(member(id));render();};});
  document.querySelectorAll('[data-pdel]').forEach(function(b){b.onclick=function(){var p=b.getAttribute('data-pdel').split(':');DRAFT[p[0]].tasks.splice(Number(p[1]),1);render();};});
  document.querySelectorAll('[data-pnote]').forEach(function(b){b.onclick=function(){var id=b.getAttribute('data-pnote'),v=document.getElementById('pn-'+id).value.trim();if(!v)return;DRAFT[id].tasks.push({id:tid(),kind:'note',title:v.slice(0,120),text:''});render();};});
  document.querySelectorAll('[data-ppublish]').forEach(function(b){b.onclick=async function(){var id=b.getAttribute('data-ppublish');if(!DRAFT[id].tasks.length)return alert('Add at least one task.');var r=await act({type:'publish_plan',id:id,plan:{tasks:DRAFT[id].tasks}});if(r.status!==200)return alert(r.body.error||'Could not publish.');delete DRAFT[id];setFlash('Plan published. The student sees it on their home page.');refresh();};});
  document.querySelectorAll('[data-review]').forEach(function(b){b.onclick=async function(){var p=b.getAttribute('data-review').split('|'),c=document.getElementById('rc-'+p[1]+'-'+p[2]);var r=await act({type:'review',studentId:p[0],attemptId:p[1],index:Number(p[2]),verdict:p[3],comment:c?c.value:''});if(r.status!==200)return alert(r.body.error||'Could not save.');refresh();};});
  document.querySelectorAll('[data-reviewall]').forEach(function(b){b.onclick=async function(){var p=b.getAttribute('data-reviewall').split('|');var r=await act({type:'review',studentId:p[0],attemptId:p[1],verdict:'agree'});if(r.status!==200)return alert(r.body.error||'Could not save.');setFlash('Marking saved.');refresh();};});
  document.querySelectorAll('[data-sdone]').forEach(function(b){b.onclick=async function(){var m=S.member;m.done=m.done||{};m.done[b.getAttribute('data-sdone')]=true;var r=await fetch('/api/student/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({done:m.done})});if(r.status!==200)alert('Not saved: we are still waiting for permission from a parent or guardian.');refresh();};});

  var at=document.querySelector('[data-addteacher]');if(at)at.onclick=async function(){var r=await act({type:'add_teacher',name:document.getElementById('tname').value,email:document.getElementById('temail').value});if(r.status!==200)return alert(r.body.error||'Could not add.');setFlash('Teacher added. One-time login for '+r.body.loginEmail+': '+r.body.loginCode+' — send it to them; they set their own password at '+location.origin+'/login.html');refresh();};
  var ib=document.querySelector('[data-importbuiltin]');if(ib)ib.onclick=async function(){if(!confirm('Load the Year 7 Maths questions now?'))return;var r=await act({type:'import_builtin'});if(r.status!==200)return alert(r.body.error||'Could not load.');setFlash('Loaded '+r.body.count+' approved items. Students can now practise.');refresh();};

  document.querySelectorAll('[data-flag]').forEach(function(el){el.onchange=async function(){await act({type:'set_flag',key:el.getAttribute('data-flag'),value:el.checked});setFlash('Setting saved.');refresh();};});
  document.querySelectorAll('[data-approve]').forEach(function(b){b.onclick=async function(){var card=b.closest('[data-req]')||b.closest('.card');var id=b.getAttribute('data-approve');var tsel=card.querySelector('[data-teacher]');var teacherId=tsel?tsel.value:'';var subs=[].slice.call(card.querySelectorAll('[data-subj]:checked')).map(function(c){return {subject:c.value,board:'No board (KS3)'};});var cs=card.querySelector('[data-child]');var r=await act({type:'approve',id:id,teacherId:teacherId,subs:subs,childId:cs?cs.value:''});if(r.status!==200)return alert(r.body.error||'Could not approve.');if(r.body.loginCode)setFlash('Approved. One-time login for '+r.body.loginEmail+': '+r.body.loginCode+' — send this to them; they set their own password on first sign-in.');refresh();};});
  document.querySelectorAll('[data-reject]').forEach(function(b){b.onclick=async function(){var r=await act({type:'reject',id:b.getAttribute('data-reject')});if(r.status!==200)return alert(r.body.error);setFlash('Rejected.');refresh();};});
  document.querySelectorAll('[data-consent]').forEach(function(b){b.onclick=async function(){if(!confirm('Confirm a parent or guardian has given permission for this child to use the platform?'))return;var r=await act({type:'record_consent',studentId:b.getAttribute('data-consent'),text:'Parental consent confirmed by super user'});if(r.status!==200)return alert(r.body.error);setFlash('Consent recorded.');refresh();};});
  document.querySelectorAll('[data-revoke]').forEach(function(b){b.onclick=async function(){var r=await act({type:'revoke',id:b.getAttribute('data-revoke')});if(r.status!==200)return alert(r.body.error);setFlash('Access paused.');refresh();};});
  document.querySelectorAll('[data-restore]').forEach(function(b){b.onclick=async function(){var r=await act({type:'restore',id:b.getAttribute('data-restore')});if(r.status!==200)return alert(r.body.error);setFlash('Access restored.');refresh();};});
  document.querySelectorAll('[data-flag-idx]').forEach(function(b){b.onclick=async function(){var r=await act({type:'handle_flag',index:Number(b.getAttribute('data-flag-idx'))});if(r.status!==200)return alert(r.body.error);setFlash('Marked handled.');refresh();};});
}
refresh();
