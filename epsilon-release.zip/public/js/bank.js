/* Question bank for staff: review, approve and add questions. */
(function(){
var EL=window.EL,esc=EL.esc,S=null,F={status:'verified',kind:'all',topic:'all'},flash='';
var TOPIC={neg:'Negative numbers',frac:'Fractions',pct:'Percentages',alg:'Algebra'},ST={verified:'waiting for approval',approved:'approved',rejected:'rejected',draft:'draft'};
function act(d){return fetch('/api/admin/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}).then(function(r){return r.json().then(function(j){return {status:r.status,body:j}})})}
function render(h){document.getElementById('app').innerHTML=h;wire()}
function preview(it){var x=EL.instantiate(it,7);return '<p class="q">'+esc(x.stem)+'</p>'+(it.type==='mcq'?'<p class="muted">Options: '+x.opts.map(esc).join(' · ')+'</p>':'')+'<p class="muted"><strong>Answer:</strong> '+esc(EL.answerText(it,x))+(x.solution?' · <strong>Solution:</strong> '+esc(x.solution):'')+'</p>'}
function list(){
  var items=(S.allItems||[]).filter(function(it){return (F.status==='all'||it.status===F.status)&&(F.kind==='all'||(F.kind==='levels')===!!it.ladder)&&(F.topic==='all'||(it.ladder?it.ladder.topic:'q')===F.topic)});
  var c={};(S.allItems||[]).forEach(function(it){c[it.status]=(c[it.status]||0)+1});
  var h='<p class="muted"><a href="/">◂ Control Room</a></p><h1>Question bank</h1>'+(flash?'<div class="card">'+esc(flash)+'</div>':'');flash='';
  h+='<div class="card"><p>'+Object.keys(ST).map(function(k){return '<span class="chip">'+(c[k]||0)+' '+ST[k]+'</span>'}).join('')+'</p><p class="muted">Students only see approved questions. A question you added must be approved by someone else (the super user can approve anything).</p>'+
    '<div class="row"><label>Status<select data-f="status">'+['all','verified','approved','rejected'].map(function(v){return '<option value="'+v+'"'+(F.status===v?' selected':'')+'>'+(v==='all'?'All':ST[v])+'</option>'}).join('')+'</select></label>'+
    '<label>Kind<select data-f="kind"><option value="all">All</option><option value="questions"'+(F.kind==='questions'?' selected':'')+'>Questions</option><option value="levels"'+(F.kind==='levels'?' selected':'')+'>Practice levels</option></select></label>'+
    '<label>Topic<select data-f="topic"><option value="all">All</option>'+Object.keys(TOPIC).map(function(k){return '<option value="'+k+'"'+(F.topic===k?' selected':'')+'>'+TOPIC[k]+' (levels)</option>'}).join('')+'<option value="q"'+(F.topic==='q'?' selected':'')+'>Other questions</option></select></label></div>'+
    '<div class="actions"><button data-add>Add a question</button>'+(items.some(function(i){return i.status==='verified'})?'<button class="ok" data-allok>Approve all '+items.filter(function(i){return i.status==='verified'}).length+' shown</button>':'')+'</div></div>';
  if(!items.length)h+='<p class="muted">Nothing here.</p>';
  items.slice(0,60).forEach(function(it){
    h+='<div class="card"><div><span class="chip">'+esc(ST[it.status]||it.status)+'</span><span class="chip">'+esc(it.ladder?(TOPIC[it.ladder.topic]||it.ladder.topic)+' level '+it.ladder.level:it.spec||'Question')+'</span>'+(it.source==='teacher'?'<span class="chip">added by '+esc(it.authorName||'staff')+'</span>':'')+'</div>'+preview(it)+
      (it.reviewNote?'<p class="muted">Note: '+esc(it.reviewNote)+'</p>':'')+
      '<div class="actions">'+(it.status!=='approved'?'<button class="ok" data-ok="'+it.id+'">Approve</button>':'')+(it.status!=='rejected'?'<button class="bad" data-no="'+it.id+'">Reject</button>':'')+(it.status!=='verified'?'<button class="ghost" data-back="'+it.id+'">Back to waiting</button>':'')+'</div></div>'});
  if(items.length>60)h+='<p class="muted">Showing 60 of '+items.length+'. Use the filters to narrow it down.</p>';
  render(h);
}
function addForm(){
  render('<p class="muted"><a href="#" data-cancel>◂ Back to the bank</a></p><h1>Add a question</h1><div class="card">'+
    '<label for="ty">Answer type</label><select id="ty"><option value="numeric">A number</option><option value="fraction">A fraction</option><option value="mcq">Multiple choice</option><option value="text">A word or phrase</option></select>'+
    '<label for="st">Question</label><textarea id="st" rows="2"></textarea>'+
    '<div id="ansbox"></div>'+
    '<div class="row"><label>Topic<input id="sp" placeholder="e.g. Number: decimals"></label><label>Unit (optional)<input id="un" placeholder="e.g. cm"></label><label>Year<select id="yr">'+['Year 7','Year 8','Year 9','Year 10','Year 11','Year 12','Year 13'].map(function(y){return '<option>'+y+'</option>'}).join('')+'</select></label><label>Difficulty (1 to 5)<select id="df"><option>1</option><option selected>2</option><option>3</option><option>4</option><option>5</option></select></label></div>'+
    '<label for="so">Worked solution</label><textarea id="so" rows="2"></textarea><label for="hi">Hint (optional)</label><input id="hi">'+
    '<div class="actions"><button data-save>Check and save</button></div><p class="muted">The server checks the question works before saving. It then waits for approval.</p></div>');
  var ty=document.getElementById('ty');function box(){var t=ty.value,h='';
    if(t==='mcq')h='<label>Options (tick the correct one)</label>'+[0,1,2,3].map(function(i){return '<div class="row"><label style="flex:0 0 auto"><input type="radio" name="cor" value="'+i+'"'+(i===0?' checked':'')+'></label><input id="op'+i+'" placeholder="Option '+(i+1)+(i>1?' (optional)':'')+'"></div>'}).join('');
    else h='<label for="an">'+(t==='fraction'?'Answer as a fraction, for example 3/4':t==='text'?'Accepted answers, separated by commas':'Answer, for example 12 or -3.5')+'</label><input id="an">'+(t==='fraction'?'<label style="font-weight:400"><input type="checkbox" id="sm"> Must be in simplest form</label>':'');
    document.getElementById('ansbox').innerHTML=h}
  ty.onchange=box;box();
  document.querySelector('[data-cancel]').onclick=function(e){e.preventDefault();list()};
  document.querySelector('[data-save]').onclick=async function(){var t=ty.value,v=function(id){var e=document.getElementById(id);return e?e.value:''},item={type:t,stem:v('st'),solution:v('so'),hints:[v('hi')],spec:v('sp'),unit:v('un'),year:v('yr'),difficulty:v('df')};
    if(t==='mcq'){item.opts=[0,1,2,3].map(function(i){return v('op'+i)});var c=document.querySelector('input[name=cor]:checked');item.correct=c?Number(c.value):0;var kept=item.opts.map(function(o,i){return o.trim()?i:-1}).filter(function(i){return i>-1});item.correct=kept.indexOf(item.correct);item.opts=item.opts.filter(function(o){return o.trim()})}
    else{item.answer=v('an');var sm=document.getElementById('sm');item.simplest=!!(sm&&sm.checked)}
    var r=await act({type:'item_add',item:item});if(r.status!==200)return alert(r.body.error||'Could not save.');flash='Saved. It is waiting for approval.';F.status='verified';await load()};
}
function wire(){
  document.querySelectorAll('[data-f]').forEach(function(s){s.onchange=function(){F[s.getAttribute('data-f')]=s.value;list()}});
  var a=document.querySelector('[data-add]');if(a)a.onclick=addForm;
  async function set(ids,st,note){var r=await act({type:'item_status',ids:ids,status:st,note:note||''});if(r.status!==200)return alert(r.body.error);flash=r.body.changed+' updated.'+(r.body.refused.length?' Not approved: '+r.body.refused.slice(0,3).join('; '):'');await load()}
  document.querySelectorAll('[data-ok]').forEach(function(b){b.onclick=function(){set([b.getAttribute('data-ok')],'approved')}});
  document.querySelectorAll('[data-no]').forEach(function(b){b.onclick=function(){var n=prompt('Why are you rejecting it? (the author sees this note)');if(n===null)return;set([b.getAttribute('data-no')],'rejected',n)}});
  document.querySelectorAll('[data-back]').forEach(function(b){b.onclick=function(){set([b.getAttribute('data-back')],'verified')}});
  var all=document.querySelector('[data-allok]');if(all)all.onclick=function(){var ids=(S.allItems||[]).filter(function(it){return it.status==='verified'&&(F.kind==='all'||(F.kind==='levels')===!!it.ladder)&&(F.topic==='all'||(it.ladder?it.ladder.topic:'q')===F.topic)}).map(function(it){return it.id});if(confirm('Approve '+ids.length+' questions? Only do this after reading them.'))set(ids,'approved')};
}
async function load(){var r=await fetch('/api/state');if(r.status===401){location.href='/login.html';return}S=await r.json();
  if(!S.me||(S.me.role!=='super'&&S.me.role!=='teacher')){render('<p class="muted">This page is for staff. <a href="/">Home</a></p>');return}list()}
load();
})();
