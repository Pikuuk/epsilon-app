/* Plan question task: answer with workings, marked on the server. */
(function(){
var EL=window.EL,esc=EL.esc,S=null,task=null,items=[];
function render(h){document.getElementById('app').innerHTML=h;wire()}
function inst(it){return EL.instantiate(it,EL.hash(S.me.id+':'+task.id+':'+it.id))}
function form(){
  var h='<p class="muted"><a href="/">◂ Home</a></p><h1>'+esc(task.title)+'</h1><p class="muted">Type your answer and show your working. Your teacher can see your working and may leave you a comment.</p>';
  if(!S.consented)h+='<div class="warnbox">You can try these, but they cannot be submitted until a parent or guardian gives permission.</div>';
  items.forEach(function(it,i){var x=inst(it);
    h+='<div class="card"><p class="q">'+(i+1)+'. '+esc(x.stem)+'</p>';
    if(it.type==='mcq')h+=x.opts.map(function(o,j){return '<label class="opt"><input type="radio" name="q'+i+'" value="'+j+'"> '+esc(o)+'</label>'}).join('');
    else h+='<label class="muted" for="a'+i+'">Answer'+(it.unit?' ('+esc(it.unit)+')':'')+(it.type==='fraction'?' (for example 3/4)':'')+'</label><input id="a'+i+'" autocomplete="off">';
    if(it.workings!==false)h+='<label class="muted" for="w'+i+'">Working (optional)</label><textarea id="w'+i+'" rows="2"></textarea>';
    h+='</div>';});
  h+='<div class="actions"><button data-submit>Submit answers</button></div>';
  render(h);
}
function results(at){
  var h='<p class="muted"><a href="/">◂ Home</a></p><h1>'+esc(task.title)+'</h1><div class="card"><strong>'+(at.finalScore!=null?at.finalScore:at.score)+' of '+at.of+' correct</strong>'+(at.reviewed?' <span class="muted">(checked by your teacher)</span>':'')+'</div>';
  at.items.forEach(function(r,i){var ok=r.review?r.final:r.correct;
    h+='<div class="card"><p class="q">'+(i+1)+'. '+esc(r.stem)+'</p><p class="'+(ok?'ok':'no')+'">'+(ok?'✓ Correct':'✗ Not yet')+' · your answer: '+esc(r.shown||'(blank)')+'</p>'+(ok?'':'<p class="muted">Answer: '+esc(r.answer)+'. '+esc(r.solution)+'</p>')+(r.review&&r.review.comment?'<div class="fb"><strong>Teacher:</strong> '+esc(r.review.comment)+'</div>':'')+'</div>';});
  h+='<div class="actions"><button data-again>Try again with the same questions</button> <a href="/"><button class="ghost">Home</button></a></div>';
  render(h);
}
async function submit(){
  var answers=items.map(function(it,i){var raw;if(it.type==='mcq'){var c=document.querySelector('input[name=q'+i+']:checked');raw=c?c.value:''}else{var a=document.getElementById('a'+i);raw=a?a.value:''}var w=document.getElementById('w'+i);return {qid:it.id,raw:raw,workings:w?w.value:''}});
  var r=await fetch('/api/student/submit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({taskId:task.id,answers:answers})});
  var j=await r.json().catch(function(){return {}});
  if(r.status!==200){alert(j.error==='consent_required'?'This cannot be submitted until a parent or guardian gives permission.':(j.error||'Could not submit.'));return}
  results(j.attempt);
}
function wire(){var b=document.querySelector('[data-submit]');if(b)b.onclick=submit;var g=document.querySelector('[data-again]');if(g)g.onclick=form}
async function load(){
  var r=await fetch('/api/state');if(r.status===401){location.href='/login.html';return}
  S=await r.json();var id=(location.search.match(/task=([\w-]+)/)||[])[1];
  var p=S.member&&S.member.plan;task=p&&p.tasks&&p.tasks.filter(function(t){return t.id===id&&t.kind==='questions'})[0];
  if(!task){render('<p class="muted">Task not found. <a href="/">Home</a></p>');return}
  items=task.qids.map(function(q){return (S.items||[]).filter(function(x){return x.id===q})[0]}).filter(Boolean);
  var last=(S.member.attempts||[]).filter(function(a){return a.taskId===task.id}).pop();
  if(last)results(last);else form();
}
load();
})();
