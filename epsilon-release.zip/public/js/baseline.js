/* Rigel: short, unmarked, adaptive check that finds a starting level per topic. */
(function(){
var EL=window.EL,esc=EL.esc,S=null,B=null;
var MAXQ=4; // at most 4 questions per topic
function items(topic,level){return (S.items||[]).filter(function(x){return x.status==='approved'&&x.ladder&&x.ladder.topic===topic&&x.ladder.level===level&&(!x.years||!x.years.length||x.years.indexOf(S.member.year)>-1)})}
function maxLevel(topic){var mx=0;EL.LADDERS.filter(function(t){return t.id===topic})[0].levels.forEach(function(l){if(items(topic,l.n).length)mx=Math.max(mx,l.n)});return mx}
function start(){
  var tps=EL.LADDERS.filter(function(t){return maxLevel(t.id)>0});
  return {i:0,plan:tps.map(function(t){var mx=maxLevel(t.id);return {topic:t.id,name:t.name,max:mx,lo:0,hi:mx+1,cur:Math.ceil(mx/2),asked:0,done:false}}),q:null,ans:''};
}
function next(){
  while(B.i<B.plan.length&&B.plan[B.i].done)B.i++;
  if(B.i>=B.plan.length){B.q=null;return false}
  var t=B.plan[B.i],its=items(t.topic,t.cur);
  if(!its.length){t.done=true;return next()}
  var seed=EL.hash(S.me.id+'rigel'+t.topic+t.cur+t.asked+Date.now()),it=its[seed%its.length],x=EL.instantiate(it,seed);
  B.q={type:it.type,ans:x.ans,fnum:x.fnum,fden:x.fden,simplest:it.simplest,stem:x.stem,unit:it.unit,level:t.cur};B.ans='';return true;
}
function answer(raw){
  var t=B.plan[B.i],ok=String(raw).trim()!==''&&EL.markLadder(B.q,raw);
  t.asked++;if(ok)t.lo=B.q.level;else t.hi=B.q.level;
  t.cur=Math.floor((t.lo+t.hi)/2);
  if(t.hi-t.lo<=1||t.asked>=MAXQ||t.cur<1)t.done=true;
}
function result(){var r={};B.plan.forEach(function(t){r[t.topic]={name:t.name,secure:t.lo,max:t.max}});return r}
async function save(res){
  var lad=S.member.lad||{};
  Object.keys(res).forEach(function(tp){lad[tp]=lad[tp]||{};for(var L=1;L<=res[tp].secure;L++){var s=lad[tp][L]||{passed:false,best:0,sets:0};if(!s.passed){s.passed=true;s.byBaseline=true}lad[tp][L]=s}});
  var base=S.member.base||{};base.Maths={at:Date.now(),topics:res};
  S.member.lad=lad;S.member.base=base;
  if(!S.consented)return false;
  var r=await fetch('/api/student/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({lad:lad,base:base})});
  return r.status===200;
}
function render(h){document.getElementById('app').innerHTML=h;wire()}
function intro(){
  var done=S.member.base&&S.member.base.Maths;
  var h='<h1>Rigel check</h1><div class="card"><p>A quick check to find the right starting level for you in each Maths topic. It is <strong>not a test and not marked</strong>.</p><p class="muted">About '+(B.plan.length*3)+' questions. If you do not know an answer, press <strong>Skip</strong>; that is fine.</p>'+(done?'<p class="muted">You did this before. Doing it again can only unlock more levels, never lock any.</p>':'')+'<div class="actions"><button data-go>Start</button></div></div>';
  if(!S.consented)h+='<div class="warnbox">Your result will not be saved yet because we are still waiting for a parent or guardian to give permission.</div>';
  render(h);
}
function question(){
  var total=B.plan.length,pct=Math.round(100*B.plan.filter(function(p){return p.done}).length/total),t=B.plan[B.i];
  render('<p class="muted">'+esc(t.name)+'</p><div class="bar" role="progressbar" aria-valuenow="'+pct+'" aria-valuemin="0" aria-valuemax="100"><i style="width:'+pct+'%"></i></div><div class="card"><p class="q">'+esc(B.q.stem)+'</p><label for="a" class="muted">Your answer'+(B.q.type==='fraction'?' (for example 3/4)':'')+'</label><input id="a" autocomplete="off" inputmode="'+(B.q.type==='fraction'?'text':'numeric')+'"><div class="actions"><button data-next>Next</button><button class="ghost" data-skip>Skip</button></div></div>');
  var a=document.getElementById('a');if(a){a.focus();a.onkeydown=function(e){if(e.key==='Enter')go(a.value)}}
}
async function finish(){
  var res=result(),saved=await save(res);
  render('<h1>All done</h1><div class="card"><p>Here is where you start:</p><ul>'+Object.keys(res).map(function(k){var r=res[k];return '<li><strong>'+esc(r.name)+':</strong> '+(r.secure?'levels 1 to '+r.secure+' unlocked, start at level '+Math.min(r.max,r.secure+1):'start at level 1')+'</li>'}).join('')+'</ul>'+(saved?'':'<p class="muted">Not saved yet: we are waiting for permission from a parent or guardian.</p>')+'<div class="actions"><a href="/practice.html"><button>Go to practice levels</button></a> <a href="/"><button class="ghost">Home</button></a></div></div>');
}
function go(raw){answer(raw);if(next())question();else finish()}
function wire(){
  var g=document.querySelector('[data-go]');if(g)g.onclick=function(){if(next())question();else finish()};
  var n=document.querySelector('[data-next]');if(n)n.onclick=function(){go(document.getElementById('a').value)};
  var k=document.querySelector('[data-skip]');if(k)k.onclick=function(){go('')};
}
async function load(){
  var r=await fetch('/api/state');if(r.status===401){location.href='/login.html';return}
  S=await r.json();
  if(!S.me||S.me.role!=='student'||!S.member){render('<h1>Rigel check</h1><p class="muted">This page is for students. <a href="/">Home</a></p>');return}
  B=start();
  if(!B.plan.length){render('<h1>Rigel check</h1><p class="muted">Nothing is ready yet. Please check back soon.</p>');return}
  intro();
}
window.BL={start:function(s){S=s;B=start();return B},next:function(){return next()},answer:answer,result:result,state:function(){return B}};
if(document.getElementById('app'))load();
})();
